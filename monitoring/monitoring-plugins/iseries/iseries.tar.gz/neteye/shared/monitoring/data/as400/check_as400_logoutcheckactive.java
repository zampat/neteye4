//Nagios Plugin to check an IBM AS/400
//
//Developed June 2003
//Last Modified September 17 2004
//
//
//Things to add/fix:
//
//Send commands with proper assistance level so screen ends up the same on different setups
//

//change log
//0.11
//Added checks for errors on login, and for invalid queue name
//
//0.12a
//Fixed tight loop eating all cpu time when not recieving input
//Several spots of code cleanups. Mainly places where I wasn't checking the return values of functions before continuing.
//
//0.13
//Logout instead of just disconnecting.
//
//0.14
//Added check for expired password
//Corrected several incorrect exit status commands
//Added check for expiring password
//
//0.15
//Minor changes to login procedure (to make it more compatible with other versions of OS/400)
//Added check for break messages on login
//Added check for command not allowed error
//
//0.15a
//Minor changes to login procedure (again to make it more compatible with other versions of OS/400)
//
//0.16
//Asthetic change to the usage output
//Added ability to check if subsystem is running
//Added ability to check number of active jobs in system
//Added ability to check if a job is running
//Added debug functionality (to help you and me solve problems!)
//Modified check for invalid user name
//Modified check for invalid password
//Removed the transmission of 'esc'(asc 27) at beginning of connection
//
//0.17
// Added fix to show active duplicated job
// Added ability to check for disabled users
//0.18
// Fixed to check for AS400 operation system version
//0.19
// Added ability to check in the users MSGQ for a string
//0.20
// Added ability to check for number of running jobs in a wrkjobq


import java.io.*;
import java.net.*;
import java.text.*;

public class check_as400{
	final static String VERSION="0.16";

	public static void printUsage(){
		System.out.println("Usage: check_as400 -H host -u user -p pass [-v var] [-w warn] [-c critical]\n");
		System.out.println("    (-h) for detailed help");
		System.out.println("    (-V) for version information\n");
	}
	
	public static void printUsageDetail(){
		System.out.println("Usage: check_as400 -H host -u user -p pass [-v var] [-w warn] [-c critical]\n");
		System.out.println("Options:\n");
		System.out.println("-H HOST\n   Name of the host to check");
		System.out.println("-u USERNAME\n   Username to login to host");
		System.out.println("-p PASSWORD\n   Password to login to host");
		System.out.println("-v STRING\n   Variable to check.  Valid variables include:");
		System.out.println("      AJ                = number of active jobs in system");
		System.out.println("      CPU               = CPU load");
		System.out.println("      DB                = DB utilization");
		System.out.println("      JOBS              = number of jobs in system");
		System.out.println("      CJ <job>          = check to see if job <job> is in the system");
		System.out.println("      MSG <user>        = check for any unanswered messages on msg queue <user>");
		System.out.println("                          Any unanswered messages causes warning status.");
		System.out.println("      MSGQ  <user> <string> = check for non existance of string in MSG");
		System.out.println("      MSGQN <user> <string> = check for existance of string in MSG");
		System.out.println("      OUTQ <queue>      = check outq files, writer and status. No writer, or");
		System.out.println("                          status of 'HLD' causes warning status. This default");
		System.out.println("                          behavior can be modified with the following options:");
		System.out.println("                             nw    = Don't go critical when no writer");
		System.out.println("                             ns    = Don't warn if status is 'HLD'");
		System.out.println("                             nf    = Ignore number of files in queue");
		System.out.println("                          NOTE: threshold values are used on number of files");
		System.out.println("      SBS <subsystem>   = check if the subsystem <subsystem> is running");
		System.out.println("                          NOTE: specify <subsystem> as library/subsystem");
		System.out.println("      US                = percent free storage");
		System.out.println("      US720             = percent free storage (old OS)");
		System.out.println("      DSKHW             = Disk Hardware status (not FAIL)");
		System.out.println("      DSPLOG            = Check log for non existance of strings");
		System.out.println("                          Obligatory options are:");
		System.out.println("                          <LOGNAME> <DAORA> <AORA> <STRING>");
		System.out.println("                 Example: QHST 030000 090000 \"this is a test string\"");
		System.out.println("      DSPLOGN           = Same as DSPLOG just checks for existance of string");
		System.out.println("      DSPLOGCPI         = Check log for non existance of a certain CPI error message");
		System.out.println("                          Obligatory options are:");
		System.out.println("                          <LOGNAME> <DAORA> <AORA> <CPINO>");
		System.out.println("                 Example: QHST 030000 090000 \"this is a test string\"");
		System.out.println("      DSPLOGCPIN        = Same as DSPLOGCPI just checks for existance of CPI message");
		System.out.println("      DSPPRB            = Check problem log");
		System.out.println("      USRPRF <user1 ...>= Check for user profiles being disabled");
		System.out.println("      WRKJOBQ <jobqueue>= Check for open jobs in a jobqueue");
		System.out.println("      CALL [<jobname>]  = Connects to system and executes a call function");
		System.out.println("-h\n   Print this help screen");
		System.out.println("-V\n   Print version information");
		System.out.println("-d\n   Be verbose (debug)\n       NOTE: Needs to be one of the first arguments to work");
		System.out.println("-D\n   Be verbose and dump screen outputs (debug)");
		System.out.println("      NOTES: Needs to be one of the first arguments to work");
		System.out.println("             When things are not working, use this flag, redirect the output to");
		System.out.println("             a file and send it to me!");
		System.out.println("\nNotes:\n -CPU, DB and US threshold's are decimal, JOBS and OUTQ are integers.\n");
	}

	public static void parseCmdLineArgs(String [] args){
		int i=0;
		int READY_FLAG=127,CRIT_FLAG=64,WARN_FLAG=32,HOST_FLAG=16,USER_FLAG=8,PASS_FLAG=4,CMD_FLAG=2,ARG_FLAG=1;
		int flag=0;

		try{
			while(flag!=READY_FLAG){
				if(args[i].equals("-H")){
					ARGS.hostName=args[++i];
					flag=flag | HOST_FLAG;
				}
				else if(args[i].equals("-u")){
					ARGS.userName=args[++i];
					flag=flag | USER_FLAG;
				}
				else if(args[i].equals("-p")){
					ARGS.passWord=args[++i];
					flag=flag | PASS_FLAG;
				}
				else if(args[i].equals("-d")){
					ARGS.DEBUG=true;
				}
				else if(args[i].equals("-D")){
					ARGS.DEBUG=ARGS.DEBUG_PLUS=true;
				}
				else if(args[i].equals("-w")){
					ARGS.tHoldWarn=(new Double(args[++i])).doubleValue();
					flag=flag | WARN_FLAG;
				}
				else if(args[i].equals("-c")){
					ARGS.tHoldCritical=(new Double(args[++i])).doubleValue();
					flag=flag | CRIT_FLAG;
				}
				else if(args[i].equals("-h")){
					printUsageDetail();
					System.exit(0);
				}
				else if(args[i].equals("-V")){
					System.out.println("Version "+VERSION);
					System.exit(0);
				}
				else if(args[i].equals("-v")){
					if(args[++i].equals("CPU")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=CPU;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("DB")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=DB;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("US")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=US;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("US720")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=US720;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("AJ")){
						ARGS.command=WRKACTJOB;
						ARGS.checkVariable=AJOBS;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}					
					else if(args[i].equals("JOBS")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=JOBS;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("MSG")){
						ARGS.command=DSPMSG;
						ARGS.checkVariable=MSG;
						ARGS.msgUser=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("MSGQ")){
						ARGS.command=DSPMSGQ;
						ARGS.checkVariable=DSPLOG;
						ARGS.msgUser=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("MSGQN")){
						ARGS.command=DSPMSGQ;
						ARGS.checkVariable=DSPLOGN;
						ARGS.msgUser=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("SBS")){
						ARGS.command=DSPSBSD;
						ARGS.checkVariable=SBS;
						ARGS.subSystem=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("CJOLD")){
						ARGS.command=DSPJOB;
						ARGS.checkVariable=DJOB;
						ARGS.job=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}					
					else if(args[i].equals("CJ")){
						ARGS.command=DSPJOB2;
						ARGS.checkVariable=DJOB;
						ARGS.job=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}					
					else if(args[i].equals("OUTQ")){
						ARGS.command=WRKOUTQ;
						ARGS.checkVariable=OUTQ;
						ARGS.outQ=args[++i];
						/*nw    = Don't warn when no writer
						ns    = Don't warn if status is 'HLD'
						nf    = Ignore number of files in queue*/
						++i;
						while(true){
							if(args[i].equals("nw")){
								ARGS.outQFlags=ARGS.outQFlags | OUTQ_NW;
								i++;
							}
							else if(args[i].equals("ns")){
								ARGS.outQFlags=ARGS.outQFlags | OUTQ_NS;
								i++;
							}
							else if(args[i].equals("nf")){
								ARGS.outQFlags=ARGS.outQFlags | OUTQ_NF;
								i++;
								flag=flag | WARN_FLAG | CRIT_FLAG;
							}
							else{
								i--;
								break;
							}
							
						}
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("DSKHW")){
						ARGS.command=WRKDSKSTS;
						ARGS.checkVariable=DSKHW;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DSPPRB")){
						ARGS.command=DSPPRB;
						ARGS.checkVariable=DSPPRB;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("CTLMSGW")){
						ARGS.command=CTLMSGW;
						ARGS.checkVariable=CTLMSGW;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DSPLOG")){
						ARGS.command=DSPLOG;
						ARGS.checkVariable=DSPLOG;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DSPLOGN")){
						ARGS.command=DSPLOG;
						ARGS.checkVariable=DSPLOGN;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DSPLOGCPI")){
						ARGS.command=DSPLOGCPI;
						ARGS.checkVariable=DSPLOG;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DSPLOGCPIN")){
						ARGS.command=DSPLOGCPI;
						ARGS.checkVariable=DSPLOGN;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("USRPRF")){
						int n = 0;
						ARGS.command=USRPRF;
						ARGS.checkVariable=USRPRF;
						ARGS.numPrefUsers = args.length - i - 1;
						if (ARGS.numPrefUsers <= 0 ) {
							System.out.println("Please specify some users");
							System.exit(WARN);
						}
						ARGS.prefUsers = new String[ARGS.numPrefUsers];
						ARGS.prefUsers[n++]=args[++i];
						while(n < ARGS.numPrefUsers) {
							ARGS.prefUsers[n++]=args[++i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("WRKJOBQ")){
						ARGS.command=WRKJOBQ;
						ARGS.checkVariable=WRKJOBQ;
						ARGS.searchString=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("CALL")){
						ARGS.command=CALLPROG;
						ARGS.checkVariable=CALLPROG;
						if (args.length > i) {
						  System.out.println("XXX" + args.length + ":" + i);
						  ARGS.job=args[++i];
						}
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
				}
				else{
					System.out.println("Unknown option ["+args[i]+"]");
					System.exit(WARN);
				}
				i++;
			}
			if(ARGS.checkVariable==US || ARGS.checkVariable==US720){
				if(ARGS.tHoldWarn<ARGS.tHoldCritical){
					System.out.println("Warning threshold should be greater than the Critical threshold.");
					System.exit(WARN);
				}
			}
			else if(ARGS.tHoldWarn>ARGS.tHoldCritical){
				System.out.println("Warning threshold should be less than the Critical threshold.");
				System.exit(WARN);
			}
		}
		catch(Exception e){
			printUsage();
			System.exit(WARN);
		}
	}

	public static void main(String [] args){
		ARGS=new CmdVars();
		
		parseCmdLineArgs(args);
		
		//establish connection to server
		if(ARGS.DEBUG) System.out.print("Establishing connection to server...");
		if(open()){		
			if(ARGS.DEBUG) System.out.println("done.\nLogging in...");
			//login
			if(login()){
				if (ARGS.DEBUG) System.out.println("Login completed.\n");
				// Get Operationg system version
				getOSVersion();
				if (ARGS.DEBUG) System.out.println("Sending command ("+ARGS.command+")...");
				//send command
				String result=runCommand();
				if(result!=null){
					if(ARGS.DEBUG) System.out.println("Command sent.\nParsing results...");
					//parse and disconnect from server
					logout(parse(result));
					if(ARGS.DEBUG) System.out.println("Finished.");
				}
				else{
					System.out.println("CRITICAL - Unexpected output on command");
					logout(CRITICAL);
				}
			}
			else{
				System.out.println("CRITICAL - Unexpected output on login");
				logout(CRITICAL);
			}
		}
		else
			System.exit(CRITICAL);
		
	}
	
	public static String runCommand(){
		
		int ch;
		/*send proper command*/
		switch(ARGS.command){
			case WRKSYSSTS:
				send("wrksyssts\r");
				/*Wait and recieve output screen*/
				return waitReceive("===>",NONE);
			case WRKOUTQ:
				send("wrkoutq "+ARGS.outQ.toLowerCase()+"*\r");
				/*Wait and recieve output screen*/
				return waitReceive("===>",GETOUTQ);
			case DSPMSG:
				send("dspmsg "+ARGS.msgUser+" msgtype(*INQ)\r");
				/*Wait and recieve output screen*/
				return waitReceive("F3=Fine",NONE);
			case DSPSBSD:
				send("dspsbsd sbsd("+ARGS.subSystem+")\r");
				/*Wait and recieve output screen*/
				return waitReceive("===>",NONE);
			case DSPJOB:
				send("dspjob "+ARGS.job+"\r");
				/*Wait and recieve output screen*/
				waitReceive("Scelta",GETJOB);
				send("1\r");
				return waitReceive("F16=",NONE);
			case DSPJOB2:
				send("wrkactjob job("+ARGS.job+")\r");
				/*Wait and recieve output screen*/
				return waitReceive("===>",NONE);
			case WRKACTJOB:
				send("wrkactjob\r");
				/*Wait and recieve output screen*/
				return waitReceive("===>",NONE);
			case WRKDSKSTS:
				send("wrkdsksts\r");
				/*Wait and recieve output screen*/
				waitReceive("===>",NONE);
				if (ARGS.DEBUG) System.out.println("Sending F11...");
                		send((char)27+"[23~");
				return waitReceive("===>",NONE);
			case DSPPRB:
				send("dspprb status(*opened)\r");
				/*Wait and recieve output screen*/
				return waitReceive("Visualizzazione problemi",DSPPRB);
			case CTLMSGW:
				send("call milobr/ctlmsgw3c\r");
				/*Wait and recieve output screen*/
				return waitReceive("CTLMSGW",CTLMSGW);
			case DSPLOG:
				send("dsplog log("+ARGS.logName+") period(("+ARGS.fromTime+") ("+ARGS.toTime+"))\r");
				/*Wait and recieve output screen*/
				return waitReceive(ARGS.searchString,DSPLOG);
			case DSPLOGCPI:
				send("dsplog log("+ARGS.logName+") period(("+ARGS.fromTime+") ("+ARGS.toTime+")) MSGID("+ARGS.searchString+")\r");
				/*Wait and recieve output screen*/
				return waitReceive("Premere Invio per continuare",DSPLOG);
			case DSPMSGQ:
				send("dspmsg msgq("+ARGS.msgUser+") start(*FIRST)\r");
				/*Wait and recieve output screen*/
				return waitReceive(ARGS.searchString,DSPLOG);
			case USRPRF:
				send("dspusrprf usrprf("+ARGS.prefUsers[0]+")\r");
				/*Wait and recieve output screen*/
				return waitReceive("Profilo utente",USRPRF);
			case WRKJOBQ:
				send("wrkjobq\r");
				/*Wait and recieve output screen*/
				return waitReceive("===>",WRKJOBQ);
			default:
				return null;
		}

	}	
	
	public static int parse(String buffer){
		switch(ARGS.command){
			case WRKSYSSTS:
				return parseWrkSysSts(buffer);
			case WRKOUTQ:
				return parseWrkOutQ(buffer);
			case DSPMSG:
				return parseDspMsg(buffer);
			case DSPMSGQ:
				return parseDspLog(buffer);
			case DSPSBSD:
				return parseDspSbsD(buffer);
			case DSPJOB:
				return parseDspJob(buffer);
			case DSPJOB2:
				return parseDspJob2(buffer);
			case WRKACTJOB:
				return parseWrkActJob(buffer);
			case WRKDSKSTS:
				return parseDskSysSts(buffer);
			case DSPPRB:
				return parseDspPrb(buffer);
			case CTLMSGW:
				return parseCtlMsgw(buffer);
			case DSPLOG:
				return parseDspLog(buffer);
			case DSPLOGCPI:
				return parseDspLogCpi(buffer);
			case USRPRF:
				return parseUsrPrf(buffer);
			case WRKJOBQ:
				return parseWrkJobQ(buffer);
		}
		return UNKNOWN;
	}	
	
	public static int getStatus(double val){
		int returnStatus=UNKNOWN;
		
		if(ARGS.checkVariable==CPU || ARGS.checkVariable==DB || ARGS.checkVariable==JOBS || ARGS.checkVariable==AJOBS || ARGS.checkVariable==OUTQ || ARGS.checkVariable==WRKJOBQ){
			if(val<ARGS.tHoldWarn){
				System.out.print("OK - ");
				returnStatus=OK;
			}
			else if(val>=ARGS.tHoldWarn && val<ARGS.tHoldCritical){
				System.out.print("WARNING - ");
				returnStatus=WARN;
			}
			else{
				System.out.print("CRITICAL - ");
				returnStatus=CRITICAL;
			}
		}
		else if(ARGS.checkVariable==US || ARGS.checkVariable==US720){
			if(val>ARGS.tHoldWarn){
				System.out.print("OK - ");
				returnStatus=OK;
			}
			else if(val<=ARGS.tHoldWarn && val>ARGS.tHoldCritical){
				System.out.print("WARNING - ");
				returnStatus=WARN;
			}
			else{
				System.out.print("CRITICAL - ");
				returnStatus=CRITICAL;
			}
		}
		else
			System.out.print("UNKNOWN - ");
			
		return returnStatus;
		
	}
		
	public static int getNumber(String buffer){
		int start;
		int num;
		String buf;

		start = buffer.indexOf(" ");
		if (start > 0) {
			buf = buffer.substring(0,start);
		} else {
			buf=buffer;
		}
		start = buf.indexOf(",");
		if (start > 0) {
			num=(new Integer(buf.substring(0,start).trim())).intValue();
		} else {
			num=(new Integer(buf.trim())).intValue();
		}
		return num;
	}

	public static int parseDspMsg(String buffer){
		if(buffer.indexOf("(Nessun messaggio disponibile)")!=-1){
			System.out.println("OK - No messages");
			return OK;
		}
		else{
			System.out.println("WARNING - Messages needing reply");
			return WARN;
		}
	}

	public static int parseWrkOutQ(String buffer){
		int returnStatus=UNKNOWN;
		int start=buffer.indexOf(ARGS.outQ.toUpperCase());
		
		int files=(new Integer((buffer.substring(start+30,start+36)).trim())).intValue();
		String writer=(buffer.substring(start+42,start+51)).trim();
		String status=(buffer.substring(start+57,start+61)).trim();
		if (ARGS.DEBUG) System.out.println("   LIB: "+buffer.substring(start+15,start+22)+" FILES: "+files+" WRITER: "+writer+" STATUS: "+status+"\n");
		/*nw    = Don't warn when no writer     = 1
		ns    = Don't warn if status is 'HLD'   = 2 
		nf    = Ignore number of files in queue = 4 */
		if(writer.equals("[8;62H")){		
			if((ARGS.outQFlags & OUTQ_NW)!=OUTQ_NW){
				System.out.print("CRITICAL - NO WRITER - ");
				returnStatus=CRITICAL;
			}
			writer="N/A";
			status=(buffer.substring(start+54,start+58)).trim();
		}

		if(returnStatus==UNKNOWN && !(status.equals("RLS"))){
			if((ARGS.outQFlags & OUTQ_NS)!=OUTQ_NS){
				System.out.print("WARNING - QUEUE NOT RELEASED - ");
				returnStatus=WARN;
			}
		}

		if(returnStatus==UNKNOWN && (ARGS.outQFlags & OUTQ_NF)!=OUTQ_NF)
			returnStatus=getStatus(files);
			
		if(returnStatus==UNKNOWN){
			System.out.print("OK - ");
			returnStatus=OK;
		}

		System.out.println("writer("+writer+") status("+status+") files("+files+")");
		
		return returnStatus;
	}

	public static int parseDspSbsD(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;

		start=buffer.indexOf("Stato:");
		String status=(buffer.substring(start+6,start+15)).trim();
		if(status.equals("ATTIVO")){
			System.out.print("OK - ");
			returnStatus=OK;
		}
		else{
			System.out.print("CRITICAL - ");
			returnStatus=CRITICAL;
		}

		System.out.println("sub system("+ARGS.subSystem+") status("+status+")");

		return returnStatus;
	}
	
	public static int parseDspJob(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;

		start=buffer.indexOf("Stato del");
		String status=(buffer.substring(start+46,start+55)).trim();
		if(status.equals("ATTIVO")){
			System.out.print("OK - ");
			returnStatus=OK;
		}
		else{
			System.out.print("CRITICAL - ");
			returnStatus=CRITICAL;
		}

		System.out.println("job("+ARGS.job+") status("+status+")");

		return returnStatus;
	}
	
	public static int parseDspJob2(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;

		start=buffer.indexOf("Nessun lavoro attivo");
		if (start == -1) {
			System.out.print("OK - job ("+ARGS.job+") active\n");
			returnStatus=OK;
		} else {
			System.out.print("CRITICAL - job ("+ARGS.job+") not active\n");
			returnStatus=CRITICAL;
		}


		return returnStatus;
	}
	
	public static int parseWrkActJob(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;		

		start=buffer.indexOf("Lavori attivi:");
		if(ARGS.DEBUG) System.out.println(buffer.substring(start+14, start+20));
		int jobs=(new Integer((buffer.substring(start+14,start+20)).trim())).intValue();

		returnStatus=getStatus(jobs);

		System.out.println(jobs+" active jobs in system|jobs="+jobs+";"+(int)(ARGS.tHoldWarn)+";"+(int)(ARGS.tHoldCritical)+";0;0");

		return returnStatus;
	}	
	
	public static int parseWrkSysSts(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;
		NumberFormat nf=NumberFormat.getInstance();

		nf.setMaximumFractionDigits(2);
		
		if(ARGS.checkVariable==CPU){
			if ((start=buffer.indexOf("% CPU utilizzata . . . . :")) != -1) {
				double cpu=(new Double(getNumber(buffer.substring(start+27,start+38)))).doubleValue();
				returnStatus=getStatus(cpu);
				System.out.println("CPU Load ("+nf.format(cpu)+"%)|cpuload="+nf.format(cpu)+";"+(int)(ARGS.tHoldWarn)+";"+(int)(ARGS.tHoldCritical)+";0;100");
			} else {
				System.out.println("UNKNOWN - CPU string not found");
			}
		}
		else if(ARGS.checkVariable==DB){
			if ((start=buffer.indexOf("% DB  . . . . ")) != -1) {
				double db=(new Double(getNumber(buffer.substring(start+19,start+28)))).doubleValue();
				returnStatus=getStatus(db);
				System.out.println("DB Load ("+nf.format(db)+"%)|dbload="+nf.format(db)+";"+(int)(ARGS.tHoldWarn)+";"+(int)(ARGS.tHoldCritical)+";0;100");
			} else {
				System.out.println("UNKNOWN - DB string not found");
			}
		}
		else if(ARGS.checkVariable==US || ARGS.checkVariable==US720){
			double percentFree,total;
			int freeStorage,usedStorage;
			String buf;

			if ((ARGS.osversion == 5.3) || (ARGS.checkVariable==US720)) {
				if(ARGS.DEBUG) System.out.print("setting US720 command for operating system == 5.3\n");
				ARGS.checkVariable=US720;
			} else {
				ARGS.checkVariable=US;
			}
			if(ARGS.checkVariable==US){
				start=buffer.indexOf("% sistema ASP utiliz");
			} else {
				start=buffer.indexOf("% ASP sistema utiliz");
			}
			if (start == -1) {
				System.out.println("UNKNOWN - ASP % string not found");
				return returnStatus;
			}
			buf=buffer.substring(start,start+80);
			start=buf.indexOf(":");
			percentFree=100.0-(new Double(getNumber(buf.substring(start+1,start+12)))).doubleValue();
			if(ARGS.checkVariable==US)
				start=buffer.indexOf("Sistema ASP");
			else
				start=buffer.indexOf("ASP sistema");
			if (start == -1) {
				System.out.println("UNKNOWN - ASP string not found");
				return returnStatus;
			}
			buf=buffer.substring(start,start+80);
			start=buf.indexOf(":");
			String tot=((buf.substring(start+1,start+12)).trim());
			total=(new Double(getNumber(tot))).doubleValue();

			returnStatus=getStatus(percentFree);
			freeStorage =(int)(total * (percentFree/100));
			usedStorage =(int)(total - freeStorage);
			System.out.println(freeStorage+" "+tot.substring(tot.length()-1)+" ("+nf.format(percentFree)+"%) free of "+(buf.substring(start+1,start+12)).trim()+"|storage="+(int)(100-percentFree)+";"+(int)(ARGS.tHoldWarn)+";"+(int)(ARGS.tHoldCritical)+";0;100");
		}
		else if(ARGS.checkVariable==JOBS){
			start=buffer.indexOf("Lavori nel sistema");
			int jobs=(new Integer((buffer.substring(start+32,start+37)).trim())).intValue();

			returnStatus=getStatus(jobs);
			
			System.out.println(jobs+" jobs in system|jobs="+jobs+";"+(int)(ARGS.tHoldWarn)+";"+(int)(ARGS.tHoldCritical)+";0;0");
		}
		
		return returnStatus;
	}
	
	public static int parseDskSysSts(String buffer)
	{
		int start=0;
		int returnStatus=UNKNOWN;
		NumberFormat nf=NumberFormat.getInstance();
		nf.setMaximumFractionDigits(2);
		
		if(ARGS.checkVariable==DSKHW){
			start=buffer.indexOf("FAIL");
			if (start != -1) {
				returnStatus=CRITICAL;
				System.out.println("CRITICAL - there is a FAILED DISK");
			} else {
				returnStatus=OK;
				System.out.println("OK - no FAILED disk detected");
			}
		}
		return returnStatus;
	}
	
	public static int parseDspPrb(String buffer)
	{
		int p1=0;
		int p2=0;
		int returnStatus=UNKNOWN;
		String buf;
		
		if(ARGS.checkVariable==DSPPRB){
			p1=buffer.indexOf("disponibile alcun record di problema che contenga i dati");
                        if(ARGS.DEBUG) System.out.println("Ssending F3...");
                        send((char)27+"3");
                        waitReceive("===>",NONE);
                        send("dspprb status(*ready)\r");
			buf=waitReceive("Visualizzazione problemi",DSPPRB);
                        if(ARGS.DEBUG) System.out.println(buf);
			p2=buf.indexOf("disponibile alcun record di problema che contenga i dati");
			if (p1 == -1) {
				returnStatus=WARN;
				p1=buffer.indexOf("Descrizione problema");
				buf=buffer.substring(p1+53,p1+120);
				System.out.println("WARNING - there are opened problems ("+buf+")");
			} else if (p2 == -1) {
				returnStatus=WARN;
				p1=buf.indexOf("Descrizione problema");
				buf=buf.substring(p1+53,p1+120);
				System.out.println("WARNING - there are ready problems ("+buf+")");
			} else {
				returnStatus=OK;
				System.out.println("OK - no open problem detected");
			}
		}
		return returnStatus;
	}
	
	public static int parseCtlMsgw(String buffer){
		int p1=0;
		int p2=0;
		int returnStatus=UNKNOWN;
		String buf;
		
		if(ARGS.checkVariable==CTLMSGW){
			p1=buffer.indexOf("SBS");
			if (p1 != -1) {
				returnStatus=WARN;
				buf=buffer.substring(p1);
				p1=buf.indexOf("*****");
				buf=buf.substring(0,p1).trim();
				System.out.println("WARNING - there is a job in 'MSGW' ("+buf+")");
			} else {
				returnStatus=OK;
				System.out.println("OK - no jobs in 'MSGW'");
			}
			send((char)27+"3");
		}
		return returnStatus;
	}

	public static int parseDspLog(String buffer){
		int p1=0;
		int p2=0;
		int returnStatus=UNKNOWN;
		String buf;
		
		if(ARGS.checkVariable==DSPLOG){
			p1=buffer.indexOf(ARGS.searchString);
			if (p1 != -1) {
				returnStatus=CRITICAL;
				buf=buffer.substring(p1);
				p2=80;
				System.out.println("CRITICAL - found string: "+buf.substring(0,p2));
			} else {
				returnStatus=OK;
				System.out.println("OK - string not found: " + ARGS.searchString);
			}
		}
		if(ARGS.checkVariable==DSPLOGN){
			p1=buffer.indexOf(ARGS.searchString);
			if (p1 == -1) {
				returnStatus=CRITICAL;
				System.out.println("CRITICAL - string not found: " + ARGS.searchString);
			} else {
				returnStatus=OK;
				System.out.println("OK - found string ("+ARGS.searchString+")");
			}
		}
		return returnStatus;
	}

	public static int parseDspLogCpi(String buffer){
		int returnStatus=OK;
		String msg = "";

		if(ARGS.checkVariable==DSPLOG) {
			if (buffer.indexOf("Nessun messaggio disponibile") == -1){
				returnStatus = CRITICAL;
				msg = "CRITICAL - "+ARGS.searchString+": was found";
			} else {
				msg = "OK - "+ARGS.searchString+": not found";
			}
		} else {
			if (buffer.indexOf("Nessun messaggio disponibile") != -1){
				returnStatus = CRITICAL;
				msg = "CRITICAL - "+ARGS.searchString+": not found";
			} else {
				msg = "OK - "+ARGS.searchString+": was found";
			}
		}

		System.out.println(msg);
		return returnStatus;
	}

	public static int parseUsrPrf(String buffer){
		int n=0;
		int returnStatus=OK;
		String msg = "";
		String pdat = "";
		String buf;
		
		if(buffer.indexOf("stato trovato il profilo utente") != -1){
			returnStatus = CRITICAL;
			msg = ARGS.prefUsers[n] + ":nonexistant";
		} else if (buffer.indexOf("DISABLED") != -1) {
			returnStatus = CRITICAL;
			msg = ARGS.prefUsers[n] + ":disabled";
			pdat = ARGS.prefUsers[n] + "=0";
		} else {
			pdat = ARGS.prefUsers[n] + "=1";
		}
		while(++n < ARGS.numPrefUsers) {
			send("\r");
			waitReceive("F3=Fine",NONE);
			send("dspusrprf usrprf("+ARGS.prefUsers[n]+")\r");
			/*Wait and recieve output screen*/
			buf=waitReceive("Profilo utente",USRPRF);
			if(buf.indexOf("stato trovato il profilo utente") != -1) {
				returnStatus = CRITICAL;
				if (msg == "") {
					msg = ARGS.prefUsers[n] + ":nonexistant";
				} else {
					msg = msg + ", " + ARGS.prefUsers[n] + ":nonexistant";
				}
				if (pdat == "") {
					pdat = ARGS.prefUsers[n] + "=0";
				} else {
					pdat = pdat + " " + ARGS.prefUsers[n] + "=0";
				}
			} else if (buf.indexOf("DISABLED") != -1) {
				returnStatus = CRITICAL;
				if (msg == "") {
					msg = ARGS.prefUsers[n] + ":disabled";
				} else {
					msg = msg + ", " + ARGS.prefUsers[n] + ":disabled";
				}
				if (pdat == "") {
					pdat = ARGS.prefUsers[n] + "=0";
				} else {
					pdat = pdat + " " + ARGS.prefUsers[n] + "=0";
				}
			} else {
				if (pdat == "") {
					pdat = ARGS.prefUsers[n] + "=1";
				} else {
					pdat = pdat + " " + ARGS.prefUsers[n] + "=1";
				}
			}
		}
		if (returnStatus != OK) {
			if (msg == "")
				System.out.println("CRITICAL - You have user problems|"+pdat);
			else
				System.out.println("CRITICAL - You have user problems ("+msg+")|"+pdat);
		} else {
			if (msg == "")
				System.out.println("OK - All checked users are enabled|"+pdat);
			else
				System.out.println("OK - All checked users are enabled ("+msg+")|"+pdat);
		}
		return returnStatus;
	}

	public static int parseWrkJobQ(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;		

		start=buffer.indexOf(ARGS.searchString.toUpperCase());
		if (start < 0) {
			returnStatus=UNKNOWN;
			System.out.println("UNKOWN - "+ARGS.searchString+" not found in wrkjobq");
		} else {
			if(ARGS.DEBUG) System.out.println(buffer.substring(start+30, start+37));
			int jobs=(new Integer((buffer.substring(start+30,start+37)).trim())).intValue();
			returnStatus=getStatus(jobs);

			System.out.println(jobs+" active jobs in queue "+ARGS.searchString);
		}
		return returnStatus;
	}	
	
	public static boolean login(){

		String buf;

		//if(ARGS.DEBUG) System.out.println("  sending hello...");
		/*send hello so the server will send login screen*/
		//send((char)27+"");

		if(ARGS.DEBUG) System.out.println("  waiting for screen...");
		/*Wait for the login screen*/
		if(waitReceive("IBM CORP",NONE)!=null){
			if(ARGS.DEBUG) System.out.println("  sending login information for "+ARGS.userName+"...");
			/*send login user/pass*/
			send(ARGS.userName+"\t");
                        send(ARGS.passWord+"\t");

                        if (ARGS.command == CALLPROG) {
                        	if(ARGS.DEBUG) System.out.println("  waiting for CALL to process...");
                                if (ARGS.job != null)
                                        send(ARGS.job+"\r");
                                else
                                        send("\r");
                                buf=waitReceive("LAVORO ESEGUITO",LOGIN);
                                if (buf != null) {
                                        if (buf.indexOf("LAVORO ESEGUITO CON ERRORI")!=-1) {
                                                System.out.println("CRITICAL - CALL executed with ERRORS");
                                                System.exit(CRITICAL);
                                        } else {
                                                System.out.println("OK - CALL executed sucessfully");
                                                System.exit(OK);
                                        }
                                } else {
                                        System.out.println("CRITICAL - No status returned from CALL");
                                        System.exit(CRITICAL);
                                }
                        }

                        if(ARGS.DEBUG) System.out.println("  waiting for login to process...");
                        send("\r");
			if(ARGS.DEBUG) System.out.println("  waiting for login to process...");
			/*Wait and recieve login screen*/
			if(waitReceive("===>",LOGIN)!=null) {
				return true;
			}
		}
		
		return false;
	}	
	
	public static boolean getOSVersion()
	{
		String buf;

		if(ARGS.DEBUG) System.out.println("Get OS Version");
		send("dspptf\r");
		/*Wait for the ptf screen*/
		buf=waitReceive("Visualizzazione stato delle PTF", NONE);
		if (buf != null) {
			if(buf.indexOf("V5R3")!=-1) {
				if(ARGS.DEBUG) System.out.println("Version V5R3 found\n");
				ARGS.osversion=5.3;
			}
		}
		//send F3
		if(ARGS.DEBUG) System.out.println("Ssending F3...");
		send((char)27+"3");
		waitReceive("===>",NONE);

		return true;
	}
	
	//Recieves all info in stream until it see's the string 'str'.
	public static String waitReceive(String str,int procedure){
		String buffer=new String();
		String actbuffer;
		boolean flag=true;

		if(ARGS.DEBUG) System.out.println("    waiting for token "+str+"...");

		buffer="";
		actbuffer="";
		try{
			while(flag){
				int ch;
				while((ch=ioReader.read())!=-1){
					actbuffer=actbuffer+(char)ch;

					if(ioReader.ready()==false)
						break;
				}
				if(ARGS.DEBUG_PLUS) System.out.println("\n**BUFFER IS:**\n"+actbuffer+"\n**END OF BUFFER**\n");
				if(procedure==LOGIN){
					if(actbuffer.indexOf("CPF1107")!=-1){
						System.out.println("CRITICAL - Login ERROR, Invalid password");
						close();
						System.exit(CRITICAL);
					}
					else if(actbuffer.indexOf("CPF1120")!=-1){
						System.out.println("CRITICAL - Login ERROR, Invalid username");
						close();
						System.exit(CRITICAL);
					}
					else if(actbuffer.indexOf("is allocated to another job")!=-1){
						if(ARGS.DEBUG) System.out.println("      responding to allocated to another job message...");
						send("\r");
						actbuffer="";
					}
					else if(actbuffer.indexOf("Password has expired")!=-1){
						send((char)27+"3");
						waitReceive("Exit sign-on",NONE);
						send("Y\r");
						System.out.println("CRITICAL - Login ERROR, Expired password");
						close();
						System.exit(CRITICAL);
					}
					else if(actbuffer.indexOf("password expires")!=  -1){
						if(ARGS.DEBUG) System.out.println("      responding to password expires message...");
						send("\r");
						actbuffer="";
					}
					else if(actbuffer.indexOf("Display Messages")!=-1){
						if(ARGS.DEBUG) System.out.println("      continuing through message display...");
						send((char)27+"3");
						actbuffer="";
					}
					else if(actbuffer.indexOf("Premere Invio per continuare.")!=  -1){
						if(ARGS.DEBUG) System.out.println("      responding to Premere Invio per continuare message...");
						send("\r");
						actbuffer="";
					}
				}
				else if(procedure==GETOUTQ){
					if(actbuffer.indexOf("(No output queues)")!=-1){
						System.out.println("CRITICAL - OUTQ "+ARGS.outQ+" does NOT exist");
						logout(CRITICAL);
					}
				}
				else if(procedure==GETJOB){
					if(actbuffer.indexOf("dei lavori duplicati")!=-1){
						if(actbuffer.indexOf("ACTIVE")!=-1){
							if(ARGS.DEBUG) System.out.println("Found duplicate sending 1 on first row!!!\n");
							send("1\r");
						} else {
							System.out.println("WARNING - Duplicate Jobs("+ARGS.job+")");
							send((char)27+"3");
							waitReceive("===>",NONE);
							logout(CRITICAL);
						}
					}
					if(actbuffer.indexOf("not found")!=-1){
						System.out.println("CRITICAL - Job("+ARGS.job+") NOT IN SYSTEM");
						logout(CRITICAL);
					}
				}
				else if(procedure==USRPRF){
					if(actbuffer.indexOf("stato trovato il profilo utente")!=-1){
						if(ARGS.DEBUG) System.out.println("    backup token received.");
						return actbuffer;
					} else if (actbuffer.indexOf("Non si dispone dell'autorizzazione per il profilo utente")!=-1) {
						System.out.println("CRITICAL - Non abilitato a vedere profili utenti!");
						logout(CRITICAL);
					}
				}
				//check for command not allowed errors
				if(procedure!=LOGIN){
					if(actbuffer.indexOf("library *LIBL not allowed")!=-1){
						send((char)27+"3");
						System.out.println("CRITICAL - Command NOT allowed");
						logout(CRITICAL);
					}
				}
				if(actbuffer.indexOf(str)!=-1)
					flag=false;
				if(flag && procedure==DSPLOG){
					int p1 = actbuffer.indexOf("Segue...");
					if(p1!=-1){
						if(ARGS.DEBUG) System.out.println("      sending PageDown to get next messages...");
						send((char)27+"[6~");
						buffer=buffer+actbuffer;
						actbuffer="";
					}
					p1 = actbuffer.indexOf("  Fine");
					if (p1 != -1) {
						flag=false;
					}
				}
				
			}
		}
		catch(Exception e) {	
			System.out.println("CRITICAL: Network error:"+e);
			return null;
		}

		if(ARGS.DEBUG) System.out.println("    token received.");

		buffer=buffer+actbuffer;
		return buffer;
	}
	
	public static void logout(int exitStatus){
		//send F3
		if(ARGS.DEBUG) System.out.println("Logging out...\n  sending F3...");
		send((char)27+"3");
		waitReceive("===>",NONE);

		if(ARGS.DEBUG) System.out.println("  requesting signoff...");
		//send logout
		send("signoff\r");
		//waitReceive(";53H",NONE);
		waitReceive("Utente",NONE);
		if(ARGS.DEBUG) System.out.println("  terminating connection...");

		close();
		if(ARGS.DEBUG) System.out.println("Logged out.");
		System.exit(exitStatus);
	}	

	//open connection to server
	public static boolean open() {
		try {
			ioSocket=new Socket(ARGS.hostName,23);
			
			ioWriter=new PrintWriter(ioSocket.getOutputStream(),true);
			ioReader=new BufferedReader(new InputStreamReader(ioSocket.getInputStream()));

			send("\n\r");

			return true;
		}
		catch(Exception e) {
			System.out.println("CRITICAL: Network error:"+e);
			return false;
		}
	}

	//close connection to server
	public static boolean close() {
		try {
			ioSocket.close();
			return true;
		}
		catch (IOException e) {
			System.out.println("CRITICAL: Network error:"+e);
			return false;
		}
	}

	//read line from stream
	public static String read(){
		String str=new String();
		try{
			str=ioReader.readLine();
		}
		catch(Exception e) {
			System.out.println("CRITICAL: Network error: "+e);
			System.exit(CRITICAL);
		}
		return str;
	}
	
	//write str to stream
	public static void send(String str){
		if(ARGS.DEBUG) System.out.println("Sending string: '" + str + "'");
		try{
			ioWriter.print(str);
			ioWriter.flush();
		}
		catch(Exception e) {
			System.out.println("CRITICAL: Network error: "+e);
			System.exit(CRITICAL);
		}	
	}	

	private static Socket ioSocket;
	private static PrintWriter ioWriter;
	private static BufferedReader ioReader;
	private static CmdVars ARGS;
	
	//These constants are for the Commands
	final static int WRKSYSSTS=0,WRKOUTQ=1,DSPMSG=2,DSPSBSD=3,DSPJOB=4,WRKACTJOB=5,WRKDSKSTS=6,DSPLOG=7,DSPPRB=8,CTLMSGW=9,USRPRF=10,DSPLOGN=11,DSPMSGQ=12,WRKJOBQ=13,DSPJOB2=14,CALLPROG=15,DSPLOGCPI=16;
	//These constants are for the variables
	final static int CPU=0,DB=1,US=2,JOBS=3,MSG=4,OUTQ=5,SBS=6,DJOB=7,AJOBS=8,DSKHW=9,US720=10;
	//These constants are for the wait recieve, controlling
	//any other logic that it should turn on. For example checking
	//for invalid login.
	final static int NONE=0,LOGIN=1,GETOUTQ=2,GETJOB=3;
	//Theses constants are the exit status for each error type
	final static int OK=0,WARN=1,CRITICAL=2,UNKNOWN=3;
	//These constants are used as flags on OUTQ
	final static int OUTQ_NW=1,OUTQ_NS=2,OUTQ_NF=4;
};
