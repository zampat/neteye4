#!/bin/sh
#
for i in Lang_Source/*.java
do
	LL=$(basename $i .java | cut -d_ -f4)
	cp $i check_as400_lang.java
	echo $i
	javac -cp jt400.jar check_as400.java check_as400_lang.java check_as400_cmd_vars.java
	if [ -n "$LL" ]
	then
		jar cfm lib/check_as400_${LL}.jar Manifest.txt check_as400 *.class
	else
		jar cfm lib/check_as400.jar Manifest.txt check_as400 *.class
	fi
done
