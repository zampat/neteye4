/**
 * 
 * LICENSE
 * 
 * Nagios Plugin to check an IBM System i (AS/400)
 * 
 * Original Community version Developed in June 2003
 * Community Version after Ver 0.18,  Modified by Shao-Pin, Cheng since 2010/06/31
 * WuerthPhoenix enhancements from Version 0.18 to V. 0.32 in branch
 * 
 * Join Version 1.3.0 to Integrate Community Distribution and Wuerth Phoenix Extensions
 * Modifications and merge Patrick Zambelli
 * Last Modified October 2014
 * 
 * Version adapted and improved by Wuerth Phoenix Jan-2010 - 2014
 * 
 * Copyright (C) 2010-2014 by Wuerth Phoenix GmbH
 * http://www.wuerth-phoenix.com
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
 --------------------------------------------------------------------------
 */

/**----------------------------------


Copyright WuerthPhoenix and Contributotrs 2003 - 2014

------------------------------------

CHANGE LOG:

0.18.01
*Fix check Expired password
*Added check DB utilization

0.18.02
*Added check QCMN JOB Transaction timeout. (Only check for CUB customize CLP result ) 
*Added debug check logout "Job ending immediately."
*Added check DISK Status.

0.18.03
*Modified the DSPMSG, see the last message and the number of message needing a reply.

0.18.04
*Added check single ASP used. 
*Added check CPUC, when use  Dynamic hardware  resource, CPU load may need consider Current processing capacity .

0.18.05.03
* Fix some German language definitions, thank Stefan Hlustik

0.18.06
* Fix ASP reach threshold cause monitor data error.
* Added check MIMIX Unprocessed Entry Count.  (Note: You should add MIMIX lib  to LIBL.)

0.18.07
* Fix V6R1 JOB DB US DBFault check

1.0.0
* Official version 1.0.0 release.
* Fix DSPMSG get null value and correct the message count.

1.0.1
* Added CPU CPUC JOBS ASP MIMIX performance data warning and critical value.

1.1.1
* Added check number of jobs in JOBQ.

1.2.0
* Added check Job Status.
* MIMIX Unprocessed Entry Count add check transfer definition and RJ link state.

1.2.4
* Added French language definitions.
* Fixed check CJ command && parse error.
* Fixed check OUTQ error with V6R1/V7R1. And can specify the library now.

1.2.5                                     
* Added check for iCluster Node Status
* Added check for iCluster Group Status
* Added check for iCluster Switch Readines  (Thanks, Mark Watts)

1.2.6                                     
* Added check for top CPU used job.

1.2.7.2                                     
* Added check for work with problems.
* Fixed French language check DISK halt. 1.2.7.1
* Fixed iCluster parse String lost define

1.2.8
* Added check for Number of file members.
* 
* 1.3.0
Integration of Wuerth Phoenix Extensions
Modifications and merge Patrick Zambelli

* 1.4.3
DSPLOG PARSER introduction
* 1.4.4
DSKHW or DSIK Fix in DiskSpace check
DISKLOAD: New Disk Load check of each device. Measures the load/activity of each disk.

List of Wuerth Phoenix integrated changes:
* //0.18
// Fixed to check for AS400 operation system version
//0.19 
// Added ability to check in the users MSGQ for a string
//0.20
// Added ability to check for number of running jobs in a wrkjobq
0.21  - Patrick Zambelli
 FIX: The wrkjobq check goes now to search in multiple pages and ignores the subsystem and reads only in queus column
 functions: (waitReceive() and parseWrkJobQ())
0.22
 parseDspJob2: Corrected check to determine if invalid job name has been specified
0.23
IBMSubstituting PrintWriter and making use of BufferedWriter with encoding of the OutputStreamWriter
functions: new decodeUTFCode() used now only for DSPJOB2
0.24 
 fix: DSKJW: Disk hardware check not scolling to next page. Make use of logic of v. 0.22 and
      changes on function runCommand() case WRKDSKSTS. Call waitReceive with procedure 'WRKDSKSTS' 
0.25
  fix: waitReceive(): excluce DSPPRB from "continue" 
      and make sure to erase buffer only iff the string has not been found yet (see comment); 
0.26
  waitRecieve(): limit number of cycles and include a sleep in order to limit max wait-runtime to about 50 sec.
0.30
   JDBC connector to read DB2 database
   Provide Argument to submit OS version
* ]]]
--------------------------------------------------------------
Current and Last Version: 1.3.0
Check_as400 merged version built on Nagios Community distribution and WuerthPhoenix enhancements
Last Modified  2014/10/15 Patrick Zambelli, for Wuerth Phoenix NetEye

Last Modified  2013/08/28 by Shao-Pin, Cheng  , Taipei, Taiwan
Mail & PayPal donate: cjt74392@ms10.hinet.net
--------------------------------------------------------------
1.4.0 Integration for checking BRM Backup Recovery Managemnet System
11-11-2014
*/


import java.io.*;
import java.net.*;
import java.text.*;
import java.util.Calendar;
import java.util.regex.Pattern;
import java.util.regex.Matcher;
//#import com.ibm.as400.access.AS400; 
//import com.ibm.as400.access.CommandCall; 
import com.ibm.as400.access.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.ResultSetMetaData;
import java.sql.DriverManager;
//import com.ibm.as400.access.AS400JDBCConnection;

public class check_as400{
	
	
	final static String VERSION="1.5.0";

	/*
    \p{Lower}       A lower-case alphabetic character: [a-z]
    \p{Upper}       An upper-case alphabetic character:[A-Z]
    \p{ASCII}       All ASCII:[\x00-\x7F]
    \p{Alpha}       An alphabetic character:[\p{Lower}\p{Upper}]
    \p{Digit}       A decimal digit: [0-9]
    \p{Alnum}       An alphanumeric character:[\p{Alpha}\p{Digit}]
    \p{Punct}       Punctuation: One of !"#$%&'()*+,-./:;<=>?@[\]^_`{|}~
    \p{Graph}       A visible character: [\p{Alnum}\p{Punct}]
    \p{Print}       A printable character: [\p{Graph}]
    \p{Blank}       A space or a tab: [ \t]
    \p{Cntrl}       A control character: [\x00-\x1F\x7F]
    \p{XDigit}      A hexadecimal digit: [0-9a-fA-F]
    \p{Space}       A whitespace character: [ \t\n\x0B\f\r]"
    */
    final static String allowedCharsRegex = "[^\\p{Graph} \n]";
    
     
	public static void printUsage(){
		safePrintln("Usage: check_as400 -H host -u user -p pass [-v var] [-w warn] [-c critical]\n");
		safePrintln("    (-h) for detailed help");
		safePrintln("    (-V) for version information\n");
	}
	
	private static void printVersion(){
		
		System.out.println("Nagios Plugin to check an IBM System i (AS/400)\n\n" +
				"Community and WuerthPhoenix NetEye Merge Version "+VERSION+"\n" +
				"to Integrate Community Distribution and Wuerth Phoenix Extensions\n\n" +
				"Version adapted and improved by Wuerth Phoenix Jan-2010 - 2014\n" +
				"Modifications and merge version by Patrick Zambelli\n" +
				"Last Modified October 2014\n\n" +
				"Original Community version Developed since June 2003\n" +
				"Community Version after Ver 0.18,  Modified by Shao-Pin, Cheng since 2010/06/31\n\n" +
				"WuerthPhoenix enhancements from Version 0.18 to V. 0.32 branch merged into this release\n" +
				"Copyright (C) 2010-2015 by Wuerth Whoenix GmbH\n" +
				"Software released unter the therms of the GNU GPLv3\n" +
				"http://www.wuerth-phoenix.com");
	}
	
	public static void printUsageDetail(){
		safePrintln("Check_as400 Version: "+VERSION);
		safePrintln("Usage: check_as400 -H host -u user -p pass [-v var] [-w warn] [-c critical]\n");
		safePrintln("Options:\n");
		safePrintln("-H HOST\n   Name of the host to check");
		safePrintln("-u USERNAME\n   Username to login to host");
		safePrintln("-p PASSWORD\n   Password to login to host");
		safePrintln("-o OS-Version\n   Provide OS version in numberic format: 5.4, 5.3, ...");
		safePrintln("-v STRING\n   Variable to check.  Valid variables include:");
		safePrintln("      AJ                = Number of active jobs in system.");
		safePrintln("      CJ <job>          = Check to see if job <job> is in the system.");
		safePrintln("      CJS <sbs> <job> [status <status>] [noperm]");
		safePrintln("                        = Check to see if job is existing in Subsystem and has this status.");
		safePrintln("                          Job checking can be controlled by :");
		safePrintln("                          status <status>	= any other status goes to critical");
		safePrintln("                          noperm 		= don't go to critical if job is not in the system");
	  //safePrintln("                          onlyone		= go to critical if job is shown twice otherwise ignore it");
		safePrintln("                          NOTE: if JobStatus is set, it has highest Priority");
		safePrintln("      JOBS              = Number of jobs in system.");
		safePrintln("      JOBQ <lib/jobq>   = Number of open jobs in JobQueue. [ Deprecated: WRKJOBQ]");
		safePrintln("      CPU               = CPU load.");
		safePrintln("      CPUC <cpuBase>    = CPU load, Consider Current processing capacity. (CPU used * VP nums / cpuBase).");
		safePrintln("                          NOTE: Specify <cpuBase>, EX: You want use 3 CPU only, but VP use more than 3.");
		safePrintln("      CPUT <job>        = Top CPU used job. The total processing unit time used by the job");
		safePrintln("                          Specify job name, ex: *ALL or QZ* or QZDASOINIT");	
		safePrintln("      US | US720        = Check free storage in percentage. Output of % and total capacity.");
		safePrintln("                          Check makes usage of ASP, the disk storage indicator.");	
		safePrintln("                          The US and US720 command have been unified. No difference.");	
		safePrintln("      DSKHW | DISK      = Check DISK Hardware Status.");
		safePrintln("      		       Identify Disks with Status FAILED, BUSY, DEGRADED, HDW FAIL or PWR LOSS");
		safePrintln("      DISKLOAD          = Check DISK Hardware Load.");
		safePrintln("                	       Identify the Load of each single disk and measure the % Load");
		safePrintln("                	       Loads higher than 80 % might lead to a performance reduction");
		safePrintln("      DSPLOG            = Check log for NON existance of strings ( command: dsplog )");
		safePrintln("                          Obligatory options are:");
		safePrintln("                          <LOGNAME> <FromHour> <ToHour> <STRING>");
		safePrintln("                 			Example: QHST 030000 090000 \"this is a test string\"");
		safePrintln("      DSPLOGN <string>  = Same as DSPLOG just checks for existance of string");
		safePrintln("    DSPLOGBRM         = Check log for the existance of Log Messages in BRMS log  regarding Msg-Id and Severity");
		safePrintln("                          BRMS = B(ackup)R(ecovery)M(anagement)S(ystem)");
		safePrintln("                          Usage: DSPLOGBRM FROM-HOUR FROM-DATE Msg-ID Expected-Severity(Bewertung)"); 
		safePrintln("                          Allowed FROM-DATE: today, yesterday, last7days");
		safePrintln("			       DSPLOGBRM 235000 051114 BRM1380 10"); 
		safePrintln("                          DSPLOGBRM 235000 today BRM1380 10"); 
		safePrintln("                          DSPLOGBRM 235000 yesterday BRM1380 10"); 
		safePrintln("      DSPLOGCPI         = [ITALIAN only] Check log for non existance of a certain CPI error message");
		safePrintln("      DSPLOGCPIN        = [ITALIAN only] Same as DSPLOGCPI just checks for existance of CPI message");
		safePrintln("      DSPLOGPARSE       = Same as DSPLOG with a Parse functionality");
		safePrintln("                          Obligatory options are:");
		safePrintln("                          <LOGNAME> <FromHour> <ToHour> <index_start> <length> <STRING>");
		safePrintln("                          Example: The String: Last value 000345 this is a test string\"");
		safePrintln("                          Example: QHST 030000 090000 -7 7 \"this is a test string\"");
		safePrintln("                          Output: 000345");
		safePrintln("      DSPPRB            = [ITALIAN only] Check the problem log as DSPLOG ( command: dspprb"); 
		safePrintln("                          Obligatory options are:");
		safePrintln("                          <LOGNAME> <DAORA> <AORA> <CPINO>");
		safePrintln("                 		   Example: QHST 030000 090000 \"this is a test string\"");
		safePrintln("      MSGQ  <user> <string> = check for NON existance of string in MSG (Command: dspmsg)");
		safePrintln("      MSGQN <user> <string> = check for existance of string in MSG (Command: dspmsg)");
		safePrintln(" 						");
		safePrintln("      USRPRF <user1 ...>= [ITALIAN only] Check for user profiles NOT being disabled");
		safePrintln("      ASP <aspNum>      = Check ASP <aspNum> used");
		safePrintln("      DB                = DB utilization. (Not available after V6R1)");
		safePrintln("      DBFault           = Pool DB/Non-DB Fault");
		safePrintln("      LOGIN             = Check if login completes.");
		safePrintln("      MSG <user>        = Check for any unanswered messages on msg queue <user>");
		safePrintln("                          Any unanswered messages causes warning status.");
		safePrintln("      OUTQ <queue>      = Check outq files, writer and status. No writer, or");
		safePrintln("                          status of 'HLD' causes warning status. This default");
		safePrintln("                          behavior can be modified with the following options:");
		safePrintln("                             nw    = Don't go critical when no writer");
		safePrintln("                             ns    = Don't warn if status is 'HLD'");
		safePrintln("                             nf    = Ignore number of files in queue");
		safePrintln("                          NOTE: threshold values are used on number of files");
		safePrintln("      CTLMSGW			= The CTLMSGW call");
		safePrintln("      SBS <subsystem>   = Check if the subsystem <subsystem> is running.");
		safePrintln("                          NOTE: specify <subsystem> as library/subsystem");
		safePrintln("      PRB               = Check if the problem was identified.");
		safePrintln("      FDN               = Number of file members; specify library/filename ");
		safePrintln("      ---------- VISION MIMIX ----------");
		safePrintln("      MIMIX <DG name>   = Check MIMIX Data Group Unprocessed Entry Count, Transfer definition, RJ link state.");
		safePrintln("      ---------- Rocket iCluster ----------");
		safePrintln("      ICNODE            = Check for any Inactive or Failed Node status.");
		safePrintln("      ICGROUP           = Check for any Inactive or Indoubt Group status.");
		safePrintln("      ICSWTCHRDY <grp>  = Check for multiple conditions for switch readiness.");
		safePrintln("         		         ");
		safePrintln("      CALL [<jobname>]  = Connects to system and executes a call function");
		safePrintln("      		     		  -v CALL ReturnString \"CALL PGM(LOG000C) PARM('7  ' 'XXXXX' '00001' '00002')\"");
		safePrintln("      JDBCQUERY [<db2 query>]  = Query a DB over a JDBC connection");
		safePrintln("                        ");
		safePrintln("-h\n   Print this help screen");
		safePrintln("-V\n   Print version information");
		safePrintln("-d\n   Be verbose (debug)\n       NOTE: Needs to be one of the first arguments to work");
		safePrintln("-D\n   Be verbose and dump screen outputs (debug)");
		safePrintln("      NOTES: Needs to be one of the first arguments to work");
		safePrintln("             When things are not working, use this flag, redirect the output to a file and send it to me!");
		safePrintln("\nNotes:\n -CPU, DB and US threshold's are decimal, JOBS, JOBQ and OUTQ ... are integers.\n");
	}

	
	/**
	 * Parse all variables and parameters according defined command call
	 * @param args
	 */
	public static void parseCmdLineArgs(String [] args){
		int i=0;
		int READY_FLAG=127,CRIT_FLAG=64,WARN_FLAG=32,HOST_FLAG=16,USER_FLAG=8,PASS_FLAG=4,CMD_FLAG=2,ARG_FLAG=1;
		int flag=0;

		try{
			while(flag!=READY_FLAG){
				if(args[i].equals("-H")){
					ARGS.hostName=args[++i];
					flag=flag | HOST_FLAG;
				}
				else if(args[i].equals("-u")){
					ARGS.userName=args[++i];
					flag=flag | USER_FLAG;
				}
				else if(args[i].equals("-p")){
					ARGS.passWord=args[++i];
					flag=flag | PASS_FLAG;
				}
				else if(args[i].equals("-o")){
					ARGS.osversion=Double.valueOf(args[++i]);
					ARGS.DO_OSCheck=false;
				}
				else if(args[i].equals("-d")){
					ARGS.DEBUG=true;
				}
				else if(args[i].equals("-D")){
					ARGS.DEBUG=ARGS.DEBUG_PLUS=true;
				}
				else if(args[i].equals("-w")){
					ARGS.tHoldWarn=(new Double(args[++i])).doubleValue();
					flag=flag | WARN_FLAG;
				}
				else if(args[i].equals("-c")){
					ARGS.tHoldCritical=(new Double(args[++i])).doubleValue();
					flag=flag | CRIT_FLAG;
				}
				else if(args[i].equals("-h")){
					printUsageDetail();
					System.exit(0);
				}
				else if(args[i].equals("-V")){
					printVersion();
					System.exit(0);
				}
				else if(args[i].equals("-v")){
					if(args[++i].equals("CPU")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=CPU;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("CPUC")){
						ARGS.command=WRKSYSACT;
						ARGS.checkVariable=CPUC;
						ARGS.cpuNum=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("CPUT")){
						ARGS.command=TOPCPUJOB;
						ARGS.checkVariable=CPUT;
						++i;
						if (args[i].equals("-w")||args[i].equals("-c")){
							ARGS.job="*ALL";
							i--;
						}
						else {
							ARGS.job=args[i];
						}
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("DB")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=DB;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("DBFault")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=DBFault;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("FDN")){
						ARGS.command=DSPFD;
						ARGS.checkVariable=FDN;
						ARGS.fdFile=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					
					// US <> US720 system version
					else if(args[i].equals("US")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=US;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("US720")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=US720;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}

					else if(args[i].equals("CMD")){
						ARGS.command=CMDCLP;
						ARGS.checkVariable=CMD;
						ARGS.cmdCL=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					
					//JOINED WITH -v DISK
					else if(args[i].equals("DISK") || args[i].equals("DSKHW")){
						ARGS.command=WRKDSKSTS;
						ARGS.checkVariable=DISK;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DISKLOAD")){
						ARGS.command=WRKDSKSTS;
						ARGS.checkVariable=DISKLOAD;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					
					else if(args[i].equals("ASP")){
						ARGS.command=WRKASPBRM;
						ARGS.checkVariable=ASP;
						ARGS.aspNums=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("PRB")){
						ARGS.command=WRKPRB;
						ARGS.checkVariable=PRB;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("MIMIX")){
						ARGS.command=DSPDGSTS;
						ARGS.checkVariable=MIMIX;
						ARGS.dgDef=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG;
					}

					else if(args[i].equals("AJ")){
						ARGS.command=WRKACTJOB;
						ARGS.checkVariable=AJOBS;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					else if(args[i].equals("CJ")){
						ARGS.command=DSPJOB;
						ARGS.checkVariable=DJOB;
						ARGS.job=decodeUTFCode(args[++i]);
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					// TODO Original WP Definition. Already prsent "somehow" in new version ?
					//else if(args[i].equals("CJ")){
					//	safePrintln("Make use of -v CHKJOBSTS");
					//	System.exit(WARN);
					//						ARGS.command=DSPJOB2;
					//						ARGS.checkVariable=DJOB;
					//						//ARGS.job=args[++i];
					//						ARGS.job=decodeUTFCode(args[++i]);
					//						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					//}
					else if(args[i].equals("JOBS")){
						ARGS.command=WRKSYSSTS;
						ARGS.checkVariable=JOBS;
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					//compatibility to WRKJOBQ
					else if(args[i].equals("JOBQ") || args[i].equals("WRKJOBQ")){
						ARGS.command=WRKJOBQ;
						ARGS.checkVariable=JOBQ;
						ARGS.jobQ=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG;
					}

					//else if(args[i].equals("SBS")){
					//	ARGS.command=DSPSBSD;
					//	ARGS.checkVariable=SBS;
					//	ARGS.subSystem=args[++i];
					//	flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					//}

					else if(args[i].equals("LOGIN")){
						ARGS.command=CMDLOGIN;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("MSG")){
						ARGS.command=DSPMSG;
						ARGS.checkVariable=MSG;
						ARGS.msgUser=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("MSGQ")){
						ARGS.command=DSPMSGQ;
						ARGS.checkVariable=vDSPLOG;
						ARGS.msgUser=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("MSGQN")){
						ARGS.command=DSPMSGQ;
						ARGS.checkVariable=vDSPLOGN;
						ARGS.msgUser=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("SBS")){
						ARGS.command=DSPSBSD;
						ARGS.checkVariable=SBS;
						ARGS.subSystem=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("CJOLD")){
						ARGS.command=DSPJOB;
						ARGS.checkVariable=DJOB;
						ARGS.job=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}	

					else if(args[i].equals("ICNODE")){
						ARGS.command=DMWRKNODE;
						ARGS.checkVariable=ICNODE;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("ICGROUP")){
						ARGS.command=DMWRKGRP;
						ARGS.checkVariable=ICGROUP;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}                    
					else if(args[i].equals("ICSWTCHRDY")){
						ARGS.command=DMSWTCHRDY;
						ARGS.checkVariable=ICSWRDY;
						ARGS.icGroup=args[++i];
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("OUTQ")){
						ARGS.command=WRKOUTQ;
						ARGS.checkVariable=OUTQ;
						ARGS.outQ=args[++i];
						/*nw    = Don't warn when no writer
							ns    = Don't warn if status is 'HLD'
							nf    = Ignore number of files in queue*/
						++i;
						while(true){
							if(args[i].equals("nw")){
								ARGS.outQFlags=ARGS.outQFlags | OUTQ_NW;
								i++;
							}
							else if(args[i].equals("ns")){
								ARGS.outQFlags=ARGS.outQFlags | OUTQ_NS;
								i++;
							}
							else if(args[i].equals("nf")){
								ARGS.outQFlags=ARGS.outQFlags | OUTQ_NF;
								i++;
								flag=flag | WARN_FLAG | CRIT_FLAG;
							}
							else{
								i--;
								break;
							}

						}
						flag=flag | CMD_FLAG | ARG_FLAG;
					}
					
					else if(args[i].equals("DSPPRB")){
						ARGS.command=DSPPRB;
						ARGS.checkVariable=DSPPRB;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					
					else if(args[i].equals("CTLMSGW")){
						ARGS.command=CTLMSGW;
						//ARGS.checkVariable=CTLMSGW; Not needed
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					
					//Search in Log
					else if(args[i].equals("DSPLOG")){
						ARGS.command=DSPLOG;
						ARGS.checkVariable=vDSPLOG;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DSPLOGN")){
						ARGS.command=DSPLOG;
						ARGS.checkVariable=vDSPLOGN;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					//Search in BRMS  Log
					else if(args[i].equals("DSPLOGBRM")){
						ARGS.command=DSPLOGBRM;
						ARGS.checkVariable=vDSPLOGN;
						//ARGS.logName=args[++i];
						ARGS.fromTime = args[++i];
						ARGS.logDate = args[++i];
						ARGS.logName = args[++i];
						ARGS.searchString = args[++i];
						while(args.length > ++i) {
							ARGS.logBRMWarnID = args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					//Search in CPI-Log
					else if(args[i].equals("DSPLOGCPI")){
						ARGS.command=DSPLOGCPI;
						ARGS.checkVariable=vDSPLOG;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					else if(args[i].equals("DSPLOGCPIN")){
						ARGS.command=DSPLOGCPI;
						ARGS.checkVariable=vDSPLOGN;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.searchString=args[++i];
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}
					
					//Search in Log
					else if(args[i].equals("DSPLOGPARSE")){
						ARGS.command=DSPLOG;
						ARGS.checkVariable=vDSPLOGPARSE;
						ARGS.logName=args[++i];
						ARGS.fromTime=args[++i];
						ARGS.toTime=args[++i];
						ARGS.startIndex=Integer.parseInt(args[++i]);
						ARGS.indexLength=Integer.parseInt(args[++i]);
						ARGS.searchString=args[++i];
						while(args.length > ++i) {
							ARGS.searchString=ARGS.searchString + " " + args[i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}

					else if(args[i].equals("USRPRF")){
						int n = 0;
						ARGS.command=USRPRF;
						//ARGS.checkVariable=USRPRF; Not needed
						ARGS.numPrefUsers = args.length - i - 1;
						if (ARGS.numPrefUsers <= 0 ) {
							safePrintln("Please specify some users");
							System.exit(WARN);
						}
						ARGS.prefUsers = new String[ARGS.numPrefUsers];
						ARGS.prefUsers[n++]=args[++i];
						while(n < ARGS.numPrefUsers) {
							ARGS.prefUsers[n++]=args[++i];
						}
						--i;
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}

					// Parse Program CALL arguments
					else if(args[i].equals("CALL")){

						ARGS.command=CALLPROG;
						ARGS.checkVariable=CALLPROG;

						if (args.length > ++i) {

							if(ARGS.DEBUG) safePrintln("Establishing connection to server...");
							if (ARGS.DEBUG) safePrintln("SearchStr:" + args.length + ":" + i + ":" + args[i]);
							ARGS.searchString=args[i];
						}

						if (args.length > ++i) {

							if (ARGS.DEBUG) safePrintln("CallStr:" + args.length + ":" + i + ":" + args[i]);
							ARGS.job=args[i];

							while (args.length > ++i) {
								if (ARGS.DEBUG) safePrintln("CallStr:" + args.length + ":" + i + ":" + args[i]);
								ARGS.job += " " + args[i];
							}
						}
						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}

					// Parse JDBC Query call arguments
					else if(args[i].equals("JDBCQUERY")){

						if(ARGS.DEBUG) safePrintln("Parsing args for JDBCQUERY...");
						ARGS.command=JDBCQUERY;
						ARGS.checkVariable=JDBCQUERY;

						//Get The query
						if (args.length > ++i) {
							if (ARGS.DEBUG) safePrintln("Query :" + args.length + ":" + i + ":" + args[i]);
							ARGS.dbQuery=args[i];
						}

						//Get The search string
						if (args.length > ++i) {
							ARGS.searchString=args[i];
						}

						//Other arguments that are not matched
						if (args.length > ++i) {
							safePrintln("Exceeding and not used argument! Num: " + i + " Content: " + args[i]+"\n"); 
						}

						flag=flag | CMD_FLAG | ARG_FLAG | WARN_FLAG | CRIT_FLAG;
					}

					else if(args[i].equals("CJS")){
						ARGS.command=CHKJOBSTS;
						ARGS.checkVariable=JOBSTS;
						ARGS.subSystem=args[++i];
						ARGS.job=args[++i];

						++i;
						while(true){
							//In this case all further addition parameters are optional
							if (i==args.length){
								flag=flag | WARN_FLAG | CRIT_FLAG; // Parameter completely set
								break;
							}
							else if(args[i].equals("status")){
								ARGS.chk_status=args[++i];
								ARGS.JobFlags=ARGS.JobFlags | JOBSTS_STATUS;
								i++;
							}
							else if(args[i].equals("noperm")){
								ARGS.JobFlags=ARGS.JobFlags | JOBSTS_NOPERM;
								i++;
							}
							else if(args[i].equals("onlyone")){
								ARGS.JobFlags=ARGS.JobFlags | JOBSTS_ONLYONE;
								i++;
							}
							else{
								i--;
								break;
							}
						}
						flag=flag | CMD_FLAG | ARG_FLAG;
					}

				}
				else{
					safePrintln("Unknown option ["+args[i]+"]");
					System.exit(WARN);
				}
				i++;
			}

			if(ARGS.checkVariable==US){
				if(ARGS.tHoldWarn<ARGS.tHoldCritical){
					safePrintln("Warning threshold should be greater than the Critical threshold.");
					System.exit(WARN);
				}
			}
			else if(ARGS.tHoldWarn>ARGS.tHoldCritical){
				safePrintln("Warning threshold should be less than the Critical threshold.");
				System.exit(WARN);
			}
		}
		catch(Exception e){
			printUsage();
			System.exit(WARN);
		}
	}

	
	
	public static void main(String [] args){
		ARGS=new check_as400_cmd_vars();
		LANG=new check_as400_lang();
		
		parseCmdLineArgs(args);
		
		//Requires a JDBC connection
		if ( ARGS.command == JDBCQUERY ){
		   performJDBC_Query();

		   
		// normal telnet session
		} else {	
			
			//establish connection to server
			if(ARGS.DEBUG) System.out.print("Establishing connection to server...");
			if(open()){
				if(ARGS.DEBUG) safePrintln("done.\nLogging in...");
				//login
				if(login()){
					if(ARGS.DEBUG) safePrintln("Login completed.\nSending command ("+ARGS.command+")...");
					
					// Get Operationg system version
					if (ARGS.DO_OSCheck) {
					   getOSVersion();
					}else{
					   if (ARGS.DEBUG) safePrintln("OS Check skipped, due to usage of -o argument.\n");
					}

					if (ARGS.DEBUG) safePrintln("Sending command ("+ARGS.command+")...");
					
					//send command
					String result=runCommand();
					if(result!=null){
						if(ARGS.DEBUG) safePrintln("Command sent.\nParsing results...");
						//parse and disconnect from server
						logout(parse(result));
						if(ARGS.DEBUG) safePrintln("Finished.");
					}
					else{
						safePrintln("CRITICAL - Unexpected output on command");
						logout(CRITICAL);
					}
				}
				else{
					safePrintln("CRITICAL - Unexpected output on login");
					logout(CRITICAL);
				}
			} else System.exit(CRITICAL);
		}
		
	}
	
	public static String runCommand(){

		/*send proper command*/
		switch(ARGS.command){
		case WRKSYSSTS:
			send("wrksyssts astlvl(*intermed)\r");
			// OLD: send("wrksyssts\r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",NONE);

		case WRKOUTQ:
			send("wrkoutq "+ARGS.outQ.toLowerCase()+"*\r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",GETOUTQ);

		case DSPMSG:
			//OLD: send("dspmsg "+ARGS.msgUser+" msgtype(*INQ)\r");
			//send("dspmsg msgq("+ARGS.msgUser+") msgtype(*INQ) astlvl(*intermed)\r");
			send("CHGVTMAP DOWN(*CTLD *CTLF *NXTSCR *ESCZ)\r");
			waitReceive("F3=",NONE);
			send("dspmsg "+ARGS.msgUser+" astlvl(*basic)\r");
			/*Wait and recieve output screen*/
			return waitReceive("F3=",NONE);

		case DSPSBSD:
			send("dspsbsd sbsd("+ARGS.subSystem+")\r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",GETSBSD);
		case DSPJOB:
			send("dspjob "+ARGS.job+"\r");
			/*Wait and recieve output screen*/
			waitReceive(LANG.SELECTION,GETJOB);
			send("1\r");
			return waitReceive("F12=",NONE);

		case WRKJOBQ:
			send("wrkjobq "+ARGS.jobQ+"* \r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",NONE);

		case CHKJOBSTS:
			send("wrkactjob sbs("+ARGS.subSystem+") job("+ARGS.job+")\r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",NONE);

		case WRKACTJOB:
			send("wrkactjob\r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",NONE);
		case TOPCPUJOB:
			send("WRKACTJOB SEQ(*CPU) JOB("+ARGS.job+")\r");
			/*Wait and recieve output screen*/
			waitReceive("===>",NONE);
			send((char)27+"-");
			waitReceive("===>",NONE);
			send((char)27+"0");
			return  waitReceive("AuxIO",NONE);
		case DSPFD:
			send("DSPFD FILE("+ARGS.fdFile+") TYPE(*ATR)\r");
			/*Wait and receive output screen*/
			waitReceive("F3=",GETFD);
			send("+24\r");
			return waitReceive("F3=",NONE);

		case CMDCLP:
			//send("CALL SJLLIB/DISKBUSY\r");
			send("CALL "+ARGS.cmdCL+" \r");
			/*Wait and recieve output screen*/
			return waitReceive("F20=",NONE);
		case WRKDSKSTS:
			send("CHGVTMAP DOWN(*CTLD *CTLF *NXTSCR *ESCZ)\r");
			waitReceive("F3=",NONE);
			send("WRKDSKSTS\r");
			/*patrick
			 * Wait and recieve output screen*/
			//waitReceive("===>",NONE);
			//waitReceive("===>",WRKDSKSTS);
			/*Wait and recieve output screen*/
			//waitReceive(LANG.REQUEST_WORD,NONE);
			String s = waitReceive(LANG.DISK_STATUS_LIST,NONE);
			if (ARGS.checkVariable == DISK){
				send((char)27+"-");
				return  waitReceive(LANG.DSK_STS_COMPRESSION,DISK);

			} else if (ARGS.checkVariable == DISKLOAD){
				
				//This Page shows the Disk Status, but needs to be refreshed to show serious values
				//Send F5
				if(ARGS.DEBUG) safePrintln("Sending F5 to refresh Disk Load status ...");
				try{
					for (int j=0;j<10;j++){
					
					   Thread.sleep(200);
					   send((char)27 + "[15~");
					   waitReceive(LANG.DISK_STATUS_LIST,NONE);			
					}
					Thread.sleep(200);
					send((char)27 + "[15~");

					s = waitReceive(LANG.DISK_STATUS_LIST,NONE);			
				} catch(Exception e) {
					s = waitReceive(LANG.DISK_STATUS_LIST,NONE);			
                		}

				if(ARGS.DEBUG) safePrintln("The new Buffer: "+s);
				return s;
			}

		case CTLMSGW:
			send("call milobr/ctlmsgw3c\r");
			/*Wait and recieve output screen*/
			return waitReceive("CTLMSGW",CTLMSGW);

			//, parsed in parseDspLog()
		case DSPLOG:
			send("dsplog log("+ARGS.logName+") period(("+ARGS.fromTime+") ("+ARGS.toTime+"))\r");
			/*Wait and recieve output screen*/
			return waitReceive(ARGS.searchString,DSPLOG);
			
			//DSPLOG for BRM System
		case DSPLOGBRM:


			int p1 = ARGS.logDate.indexOf("today");
			if (p1 != -1) {
				DateFormat dateFormat = new SimpleDateFormat("ddMMyy");
				Calendar cal = Calendar.getInstance();
				//System.out.println(dateFormat.format(cal.getTime()));
				ARGS.logDate = dateFormat.format(cal.getTime()).toString(); 
			}
			
			p1 = ARGS.logDate.indexOf("yesterday");
			if (p1 != -1) {
				DateFormat dateFormat = new SimpleDateFormat("ddMMyy");
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DATE, -1);
				//System.out.println(dateFormat.format(cal.getTime()));
				ARGS.logDate = dateFormat.format(cal.getTime()).toString(); 
			}

			p1 = ARGS.logDate.indexOf("last7days");
			if (p1 != -1) {
				DateFormat dateFormat = new SimpleDateFormat("ddMMyy");
				Calendar cal = Calendar.getInstance();
				cal.add(Calendar.DATE, -7);
				//System.out.println(dateFormat.format(cal.getTime()));
				ARGS.logDate = dateFormat.format(cal.getTime()).toString(); 
			}
		
			 if(ARGS.DEBUG) safePrintln ("Sending: send(DSPLOGBRM PERIOD(("+ARGS.fromTime+" "+ARGS.logDate+")) MSGID("+ARGS.logName+")");	
			send("DSPLOGBRM PERIOD(("+ARGS.fromTime+" "+ARGS.logDate+")) MSGID("+ARGS.logName+")\r");

			/*Wait and recieve output screen*/
			waitReceive("Alternativsicht" ,DSPLOG);

			/*
			* Find the IBM Char code:
			* $ ncat -l 12345 | hexdump -C
			* telnet localhost 12345
			* Escape character is '^]'.
			* ^[[24~^[[20~^[[19~^[[6~^[[24~^[[20~^[[19~^[[20~
			*/
			//Sending F11
			if(ARGS.DEBUG) safePrintln("Sending F11: " + ((char)27 + "[23~"));
			//send((char)27+"10");
			send((char)27 + "[23~");

			// Parse Screen holding the MSG-ID and Bewertung ID ( output id )
			return waitReceive(ARGS.logName , DSPLOG);
			
		case DSPMSGQ:
			send("dspmsg msgq("+ARGS.msgUser+") start(*FIRST)\r");
			/*Wait and recieve output screen*/
			return waitReceive(ARGS.searchString,DSPLOG);
			
			
		case DSPLOGCPI:
			send("dsplog log("+ARGS.logName+") period(("+ARGS.fromTime+") ("+ARGS.toTime+")) MSGID("+ARGS.searchString+")\r");
			/*Wait and recieve output screen*/
			return waitReceive(LANG.EnterToContinue,DSPLOG);

			// WP Function
		case DSPPRB:
			send("dspprb status(*opened)\r");
			/*Wait and recieve output screen*/
			return waitReceive(LANG.LIST_END,DSPPRB);

		

		case USRPRF:
			send("dspusrprf usrprf("+ARGS.prefUsers[0]+")\r");
			/*Wait and recieve output screen*/
			return waitReceive(LANG.UserProfile,USRPRF);

		case WRKASPBRM:
			send("CHGVTMAP DOWN(*CTLD *CTLF *NXTSCR *ESCZ)\r");
			waitReceive("F3=",NONE);
			send("WRKASPBRM ASP("+ARGS.aspNums+")\r");
			/*Wait and recieve output screen*/
			waitReceive("F3=",NONE);
			send((char)27+"-");
			return  waitReceive("Threshold",NONE);
		case WRKSYSACT:
			send("WRKSYSACT\r");
			/*Wait and recieve output screen*/
			return waitReceive("processing",NONE);
		case WRKPRB:
			send("WRKPRB\r");
			/*Wait and recieve output screen*/
			return waitReceive("F3=",NONE);
		case DSPDGSTS:
			send("DSPDGSTS DGDFN("+ARGS.dgDef+") VIEW(*MERGED)\r");
			/*Wait and recieve output screen*/
			return waitReceive("Restart statistics",NONE);
		case DMWRKNODE:
			send("CHGCURLIB CURLIB(ICLUSTER)\r");
			waitReceive("changed to ICLUSTER",NONE);
			send("CHGVTMAP DOWN(*CTLD *CTLF *NXTSCR *ESCZ)\r");
			waitReceive("F3=",NONE);
			send("DMWRKNODE \r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",NONE);
		case DMWRKGRP:
			send("CHGCURLIB CURLIB(ICLUSTER)\r");
			waitReceive("changed to ICLUSTER",NONE);
			send("CHGVTMAP DOWN(*CTLD *CTLF *NXTSCR *ESCZ)\r");
			waitReceive("F3=",NONE);
			send("DMWRKGRP \r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",NONE);

		case DMSWTCHRDY:
			send("CHGCURLIB CURLIB(ICLUSTER)\r");
			waitReceive("changed to ICLUSTER",NONE);
			send("CHGVTMAP DOWN(*CTLD *CTLF *NXTSCR *ESCZ)\r");
			waitReceive("F3=",NONE);
			send("DMSWTCHRDY ICGROUP("+ARGS.icGroup+") \r");
			/*Wait and recieve output screen*/
			return waitReceive("===>",NONE);

		case CMDLOGIN:
			safePrintln("OK - Login completed successfully");
			logout(OK);

		case CALLPROG:
			if(ARGS.DEBUG) safePrintln("  Going to extend the CMD line to 180 characters: CALL QCMD");
			send("CALL QCMD\r");
			waitReceive("===>",NONE);

			if(ARGS.DEBUG) safePrintln("  waiting for CALL to process...");
			if (ARGS.job != null)
				send(ARGS.job+"\r");
			else
				send("\r");
			return waitReceive("Immettere",NONE);

		case JDBCQUERY:
			if(ARGS.DEBUG) safePrintln("  Not to be run in a telnet sesseion. End !");
			return null;

		default:
			return null;
		}

	}	
	
	public static int parse(String buffer){
		switch(ARGS.command){
			case WRKSYSSTS:
				return parseWrkSysSts(buffer);
				
			case DSPMSG:
				return parseDspMsg(buffer);
			
			case DSPSBSD:
				return parseDspSbsD(buffer);
			case DSPJOB:
				return parseDspJob(buffer);
//			case DSPJOB2:
//				return parseDspJob2(buffer);
			case WRKJOBQ:
				return parseWrkJobq(buffer);
				
			case WRKACTJOB:
				return parseWrkActJob(buffer);
			case TOPCPUJOB:
				return parseWrkActJobTop(buffer);
			case CMDCLP:
				return parseCmdClp(buffer);
			case WRKDSKSTS:
				return parseWrkDskSts(buffer);
			case DSPPRB:
				return parseDspPrb(buffer);
			case CTLMSGW:
				return parseCtlMsgw(buffer);
			
			case DSPLOG:
				return parseDspLog(buffer);

			case DSPLOGBRM:
				return parseDspLogBRM(buffer);
			case DSPMSGQ:
				return parseDspLog(buffer);
			
				
			case DSPLOGCPI:
				return parseDspLogCpi(buffer);
				
			case USRPRF:
				return parseUsrPrf(buffer);
			
			case WRKOUTQ:
				return parseWrkOutQ(buffer);
				
			case WRKASPBRM:
				return parseWrkAspBrm(buffer);
			case WRKSYSACT:
				return parseWrkSysAct(buffer);
			case DSPDGSTS:
				return parseDspDgSts(buffer);
			case CHKJOBSTS:
				return parseChkJobSts(buffer);
			case WRKPRB:
				return parseWrkPrb(buffer);
			case DSPFD:
		      	return parseDspFd(buffer);
		    case DMSWTCHRDY:
		    	return parseICSwRdySts(buffer);
		    case DMWRKGRP:
		    	return parseICGrpSts(buffer);
		    case DMWRKNODE:
		    	return parseICNodeSts(buffer);
		    	
			case CALLPROG:
				return parseCallProg(buffer);
					
			
		}
		return UNKNOWN;
	}	
	
	
	private static int getStatus(double val){
		int returnStatus=UNKNOWN;
		
		if(ARGS.checkVariable==CPU || ARGS.checkVariable==DB || ARGS.checkVariable==JOBS || ARGS.checkVariable==AJOBS || ARGS.checkVariable==OUTQ || ARGS.checkVariable==DBFault || ARGS.checkVariable==CMD || ARGS.checkVariable==ASP || ARGS.checkVariable==CPUC || ARGS.checkVariable==CPUT || ARGS.checkVariable==MIMIX || ARGS.checkVariable==JOBQ || ARGS.checkVariable==FDN  ){
			if(val<ARGS.tHoldWarn){
				System.out.print("OK - ");
				returnStatus=OK;
			}
			else if(val>=ARGS.tHoldWarn && val<ARGS.tHoldCritical){
				System.out.print("WARNING - ");
				returnStatus=WARN;
			}
			else{
				System.out.print("CRITICAL - ");
				returnStatus=CRITICAL;
			}
		}
		//else if(ARGS.checkVariable==US){
		else if(ARGS.checkVariable==US || ARGS.checkVariable==US720){
			if(val>ARGS.tHoldWarn){
				System.out.print("OK - ");
				returnStatus=OK;
			}
			else if(val<=ARGS.tHoldWarn && val>ARGS.tHoldCritical){
				System.out.print("WARNING - ");
				returnStatus=WARN;
			}
			else{
				System.out.print("CRITICAL - ");
				returnStatus=CRITICAL;
			}
		}
		else
			System.out.print("UNKNOWN - ");
			
		return returnStatus;
		
	}
		
	public static int parseDspMsg(String paramString) {
         if(paramString.indexOf(LANG.NO_MESSAGES_AVAILABLE)!=-1){
         		if(paramString.indexOf(LANG.NO_MESSAGES_AVAILABLE)<paramString.indexOf(LANG.MSG_NOT_NEED_REPLY)){
                 safePrintln("OK - No messages | msgnum=0cnt;;;0; ");
                 return 0;
            }
         }
	 if (ARGS.DEBUG) safePrintln("   DEBUG:parseDspMsg:"+paramString+"\n");
         //Only display last MSG.
         int i = paramString.indexOf(LANG.MSG_NEED_REPLY, 0);
         int j = paramString.indexOf(" (", 0);
         i += LANG.MSG_NEED_REPLY_NUM;
         //j -= 1;
         String str1 = paramString.substring(i, j);
         //Count MSG num 
         int p=0;
         boolean botflag=true;
         int count = 0;
         while(botflag || p >20){
           int k = paramString.indexOf("F1=Help", 0);
           k -= 1;    
           if(paramString.indexOf(LANG.MSG_NOT_NEED_REPLY)!=-1){
             botflag=false;
             k = paramString.indexOf(LANG.MSG_NOT_NEED_REPLY, 0);
             k -= 27;
           }
           String str3 = paramString.substring(i, k);
           String[] str4=new String[str3.length()];
           for(int l = 0; l < str4.length;l++) {
              str4[l]=str3.substring(l,l+1);
              if(str4[l].equals("(")) {
                       count++;
              }
           }
           send((char)27+"z");
           paramString=waitReceive("F3=",NONE);
           p++;
         }	
     
        //MSG detial
         try {
                 String str2 = new String(str1.getBytes("ISO-8859-15"), "UTF-8");
                 safePrintln(str2+" ( "+count+" "+LANG.MSG_NEED_REPLY+") | msgnum="+count+"cnt;;;0; "); 
         }
         catch (UnsupportedEncodingException localUnsupportedEncodingException) {
                 System.err.println(localUnsupportedEncodingException);
         }
         return 1;
	}		

	/**
	 * 
	 * @param buffer
	 * @return
	 */
	public static int parseWrkOutQ(String buffer){
		
		int returnStatus=UNKNOWN;
		int start=buffer.indexOf(ARGS.outQ.toUpperCase());
		/*
		 * OLD WP CODE:
		 * String nf=(buffer.substring(start+30,start+38)).trim();
		 * String writer=(buffer.substring(start+42,start+52)).trim();
		 * String status=(buffer.substring(start+57,start+62)).trim();
		 * if (ARGS.DEBUG) safePrintln(":"+nf+":");
		 * if (ARGS.DEBUG) safePrintln(":"+writer+":");
		 * if (ARGS.DEBUG) safePrintln(":"+status+":");
		 * int files=(new Integer(nf)).intValue();
		 * if (ARGS.DEBUG) safePrintln("   LIB: "+buffer.substring(start+15,start+22)+" FILES: "+files+" WRITER: "+writer+" STATUS: "+status+"\n");
		 * 
		 * /*nw    = Don't warn when no writer     = 1
		 * 	ns    = Don't warn if status is 'HLD'   = 2
		 * 	nf    = Ignore number of files in queue = 4
		 */

		if (ARGS.outQ.toUpperCase().indexOf("/") != -1){
			String[] array = ARGS.outQ.toUpperCase().split("/");
			start=buffer.indexOf(array[1]);
		}

		int files=(new Integer((buffer.substring(start+26,start+38)).trim())).intValue();
		String writer=(buffer.substring(start+42,start+53)).trim(); //V6 head 44 ok
		String status=(buffer.substring(start+60,start+63)).trim(); //V6 end  63 ok 
		// nw    = Don't warn when no writer       = 1
		// ns    = Don't warn if status is 'HLD'   = 2 
		// nf    = Ignore number of files in queue = 4 
		if(writer.equals("[8;64H") || writer.equals("[8;62H")){		
			if((ARGS.outQFlags & OUTQ_NW)!=OUTQ_NW){
				System.out.print("CRITICAL - NO WRITER - ");
				returnStatus=CRITICAL;
			}
			writer="N/A";
			status=(buffer.substring(start+54,start+59)).trim();
		}

		if(returnStatus==UNKNOWN && !(status.equals("RLS"))){
			if((ARGS.outQFlags & OUTQ_NS)!=OUTQ_NS){
				System.out.print("WARNING - QUEUE NOT RELEASED - ");
				returnStatus=WARN;
			}
		}

		if(returnStatus==UNKNOWN && (ARGS.outQFlags & OUTQ_NF)!=OUTQ_NF)
			returnStatus=getStatus(files);

		if(returnStatus==UNKNOWN){
			System.out.print("OK - ");
			returnStatus=OK;
		}

		safePrintln("writer("+writer+") status("+status+") files("+files+")");

		return returnStatus;
	}

	public static int parseDspSbsD(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;

		start=buffer.indexOf(LANG.SBS_NOTACTIVE);                                                   
		if (start != -1 ){ 
			safePrintln("CRITICAL - The subsystem ("+ARGS.subSystem+") could not be found on the system ");
  			returnStatus=CRITICAL;                                                              
  			return returnStatus;                                                                
  		}  
  
		start=findToken(buffer,":",4)+1;
		String status=(buffer.substring(start,start+9)).trim();
		if(ARGS.DEBUG) safePrintln("Parsed SBS Status:"+status);

		if(status.equals(LANG.ACTIVE)){
			System.out.print("OK - ");
			returnStatus=OK;
		}
		else{
			System.out.print("CRITICAL - ");
			returnStatus=CRITICAL;
		}

		safePrintln("subsystem("+ARGS.subSystem+") status("+status+")");

		return returnStatus;
	}
	
	/**
	 * 
	 * @param buffer
	 * @return
	 */
	public static int parseDspJob(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;

		start=findToken(buffer,":",5)+1;
		String status=(buffer.substring(start,start+10)).trim();
		if(status.equals(LANG.ACTIVE)){
			System.out.print("OK - ");
			returnStatus=OK;
		}
		else{
			System.out.print("CRITICAL - ");
			returnStatus=CRITICAL;
		}

		safePrintln("job("+ARGS.job+") status("+status+")");

		return returnStatus;
	}
	
	/*
	 * 
	 * Original function in WP check. Should not be needed anymore
	 */
//	public static int parseDspJob2(String buffer){
//		int start=0;
//		int returnStatus=UNKNOWN;
//	
//		//Patrick
//		//Find the job in the page
//		start=buffer.indexOf(ARGS.job);
//		if (buffer.indexOf("Nessun lavoro attivo") != -1) {
//			safePrint("CRITICAL - job ("+ARGS.job+") not active|status=0\n");
//       	                returnStatus=CRITICAL;
//		} else 	if (buffer.indexOf("non valido") != -1){
//			safePrint("UNKNOWN - The name of the specified job "+ARGS.job+" is invalid\n");
//                        returnStatus=UNKNOWN;
//		} else if ((buffer.indexOf("Lavori attivi:") != -1 ) && (start != -1)) {
//			safePrint("OK - job ("+ARGS.job+") active|status=1\n");
//                        returnStatus=OK;
//		} else {
//
//			safePrint("UNKNOWN - It was not possible to determine the status of the job "+ARGS.job+" on the system\n");
//        	        returnStatus=UNKNOWN;
//		}
//
//
//		return returnStatus;
//	}
	
	
	/**
	 * Command: DSPFD
	 * FDN               = Number of file members; specify library/filename 
	 */
	public static int parseDspFd(String buffer){
			
	    int start=0;
	    int returnStatus=UNKNOWN;
	   
	   	if(ARGS.checkVariable==FDN){
	    	 start=findToken(buffer,":",2)+1;
	     	double fd=(new Double(checkDouble((buffer.substring(start,start+17)).trim()))).doubleValue();
	     
	     	returnStatus=getStatus(fd);
	     
	     	safePrintln(ARGS.fdFile+" Member count "+fd+"| jobs="+fd+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
	   	}
	   	return returnStatus;
	}
 
	/**
	 * Commented section is orig. from WP check
	 * @param buffer
	 * @return
	 */
	public static int parseWrkActJob(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;		

//		start=buffer.indexOf("Lavori attivi:");
//		if(ARGS.DEBUG) safePrintln(buffer.substring(start+14, start+20));
//		int jobs=(new Integer((buffer.substring(start+14,start+20)).trim())).intValue();
		
		start=findToken(buffer,":",7)+1;
		int jobs=(new Integer((buffer.substring(start,start+8)).trim())).intValue();

		returnStatus=getStatus(jobs);

		safePrintln(jobs+" active jobs in system | jobs="+jobs+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");

		return returnStatus;
	}	
	
	

	public static int parseWrkActJobTop(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;
		int start0=0;
		int start1=0;		
		//JOB Name
		start0=findToken(buffer,"CPU %",2)+40;
		String topjobname=(new String((buffer.substring(start0,start0+11)).trim()));
		//CPU
		start=findToken(buffer,"CPU %",2)+69;
		double topcpujob=(new Double((buffer.substring(start,start+12)).trim())).doubleValue();
		//AuxIO
		start1=findToken(buffer,"CPU %",2)+93;
		int topcpuio=(new Integer((buffer.substring(start1,start1+6)).trim())).intValue();
		
		returnStatus=getStatus(topcpujob);

		safePrintln("JOB:"+topjobname+", Total CPU Time:"+topcpujob+", AuxIO:"+topcpuio+" | cput="+topcpujob+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");

		return returnStatus;
	}	

	/*
	 * 
	 */
	public static int parseWrkJobq(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;		
    
    if(buffer.indexOf("RLS")!=-1){
			start=findToken(buffer,"RLS",1)-30;
		}
		else if (buffer.indexOf("HLD")!=-1){
			start=findToken(buffer,"HLD",1)-30;
		}
		else{
			safePrintln(ARGS.jobQ+" job Queues *NOT FOUND* or Damaged.");
			return CRITICAL;
		}
    
		int jobQs=(new Integer((buffer.substring(start,start+12)).trim())).intValue();

		returnStatus=getStatus(jobQs);

		safePrintln(jobQs+" jobs in "+ARGS.jobQ+" job queue. | jobqs="+jobQs+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");

		return returnStatus;
	}
	
	
	
	public static int parseChkJobSts(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;
		
		// Priority :
		// 1st : Jobstatus
		// 2nd : Existence
		
		// Check if job is in the system
		if(buffer.indexOf(LANG.NO_JOB_TO_DISPLAY)!=-1){
			if((ARGS.JobFlags&JOBSTS_NOPERM)!=JOBSTS_NOPERM)
			{
				safePrintln("CRITICAL - No Job "+ARGS.job+" in Subsystem "+ ARGS.subSystem);
				logout(CRITICAL);
			}
			else 
			{
				safePrintln("INFORMATION - No Job "+ARGS.job+" in Subsystem "+ ARGS.subSystem);	
				logout(OK);
			}
		}
		
		start=findToken(buffer,ARGS.job,2);
		String status=(buffer.substring(start+53,start+60)).trim();
		if(status.equals(ARGS.chk_status)){
			System.out.print("OK - ");
			returnStatus=OK;
			}
		else{
			if((ARGS.JobFlags & JOBSTS_STATUS) == JOBSTS_STATUS)
			{
			 System.out.print("CRITICAL - ");
    		 returnStatus=CRITICAL;
			}
			else returnStatus=OK;
    	}
		
		if (ARGS.DEBUG){
			safePrintln("Start : "+start);
		}
		safePrintln("job("+ARGS.subSystem+"/"+ARGS.job+") status("+status+")");

		return returnStatus;
	}	
	
	/**
	 * Search the Start-Index in provided String
	 * @param buffer
	 * @param token
	 * @param instance
	 * @return start index
	 */
	public static int findToken(String buffer, String token, int instance){
		
		//int index=0,start=-1,newStart=0;
		int index=0,start=-1;
		
		while(index<instance){
			start=buffer.indexOf(token,start+1);
			if(start!=-1)
				index++;
			else{
				safePrintln("Parsing ERROR!");
				logout(CRITICAL);
			}
		}
		return start;
	}

	/**
	 * Manually replace the , -> .
	 * @param buffer
	 * @return
	 */
	public static String checkDouble(String buffer){
		return buffer.replace(',','.');
	}
	
	/**
	 * Parser of the System Status Page
	 * This function is called for parsing the status of:
	 * -
	 * - US / US720: Memory usage
	 * 
	 */
	private static int parseWrkSysSts(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;
		NumberFormat nf=NumberFormat.getInstance();
		nf.setMaximumFractionDigits(2);

		if(ARGS.checkVariable==CPU){
			start=findToken(buffer,":",3)+1;
			double cpu=(new Double(checkDouble((buffer.substring(start,start+11)).trim()))).doubleValue();

			returnStatus=getStatus(cpu);

			safePrintln("CPU Load ("+nf.format(cpu)+"%) | CPU="+nf.format(cpu)+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
		}

		else if(ARGS.checkVariable==DB){
			if(buffer.indexOf(LANG.DB_CAPABILITY)!=-1){
				start=findToken(buffer,":",5)+1;
				double db=(new Double(checkDouble((buffer.substring(start,start+11)).trim()))).doubleValue();

				returnStatus=getStatus(db);

				safePrintln("DB Load ("+nf.format(db)+"%) | DBload="+nf.format(db)+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
			}
			else{
				returnStatus=WARN;
				safePrintln("DB Load NOT available after OS V6R1");
			}

		}
		else if(ARGS.checkVariable==US || ARGS.checkVariable==US720) {

			double percentFree,total,percentUsed,USwar,UScri;
			//If reach QSTGLOWLMT
			int stgcon=0;
			int aspcol=11;
			if(buffer.indexOf("Critical storage condition exists")!=-1){
				stgcon = 15;
				aspcol = 8;
			}

			// Reading the Percentage of ASP usage:
			// sistema ASP utiliz . :    41,9826 
			start=findToken(buffer,":",10)+1+stgcon;
			percentUsed=(new Double(checkDouble(buffer.substring(start,start+aspcol)))).doubleValue();
			if(ARGS.DEBUG) safePrintln("Disk perctUsed: "+percentUsed);
			start=findToken(buffer,":",10)+1+stgcon;
			percentFree=100.0-(new Double(checkDouble(buffer.substring(start,start+aspcol)))).doubleValue();
			if(ARGS.DEBUG) safePrintln("Disk perctFree: "+percentFree);
			USwar=100-ARGS.tHoldWarn;
			UScri=100-ARGS.tHoldCritical;

			//Find Disk Capability in GB
			// Sistema ASP  . . . . . :    493,9 G 
			int p1 = buffer.indexOf(LANG.DISK_CAPACITY);
			if(p1 == -1){
				p1 = buffer.indexOf(LANG.DISK_CAPACITY_ALT);
			}
			if(p1 != -1){
				String buf = buffer.substring(p1+10,p1+35).trim();
				start=findToken(buf,":",1)+1;
				String tot=((buf.substring(start,start+9))).trim();
				buffer = buf;

			// Shoulb the a % capacity of DB  % capacit DB  . . . . . :       41,1
			//} else if(buffer.indexOf(LANG.DB_CAPABILITY)!=-1){
			//	start=findToken(buffer,":",6)+1;
			//
			} else{
				start=findToken(buffer,":",8)+1;
				//start=findToken(buffer,":",11)+1;
			}
			String tot=((buffer.substring(start,start+11))).trim();
			if(ARGS.DEBUG) safePrintln("Disk Total: "+tot);
			total=(new Double(checkDouble(tot.substring(0,tot.length()-1)))).doubleValue();

			returnStatus=getStatus(percentFree);

			safePrintln(nf.format(total*(percentFree/100))+" "+tot.substring(tot.length()-1)+" ("+nf.format(percentFree)+"%) free of "+((buffer.substring(start,start+11))).trim()+" | ASP="+nf.format(percentUsed)+"%;"+USwar+";"+UScri+";0; ");
		}

		/*
		 * ORIG WP US check block. Should work with new universal structure
		 * else if(ARGS.checkVariable==US || ARGS.checkVariable==US720){
			double percentFree,total;
			int freeStorage,usedStorage;
			String buf;

			if ((ARGS.osversion == 5.3) || (ARGS.checkVariable==US720)) {
				if(ARGS.DEBUG) safePrint("setting US720 command for operating system == 5.3\n");
				ARGS.checkVariable=US720;
			} else {
				ARGS.checkVariable=US;
			}
			if(ARGS.checkVariable==US){
				start=buffer.indexOf("% sistema ASP ");
			} else {
				start=buffer.indexOf("% ASP sistema ");
			}
			if (start == -1) {
				safePrintln("UNKNOWN - ASP % string not found");
				return returnStatus;
			}
			buf=buffer.substring(start,start+80);
			start=buf.indexOf(":");
			percentFree=100.0-(new Double(getNumber(buf.substring(start+1,start+12)))).doubleValue();
			if(ARGS.checkVariable==US)
				start=buffer.indexOf("Sistema ASP");
			else
				start=buffer.indexOf("ASP sistema");
			if (start == -1) {
				safePrintln("UNKNOWN - System ASP string not found");
				return returnStatus;
			}
			buf=buffer.substring(start,start+80);
			start=buf.indexOf(":");
			String tot=((buf.substring(start+1,start+12)).trim());
			total=(new Double(getNumber(tot))).doubleValue();

			returnStatus=getStatus(percentFree);
			freeStorage =(int)(total * (percentFree/100));
			usedStorage =(int)(total - freeStorage);
			safePrintln(freeStorage+" "+tot.substring(tot.length()-1)+" ("+nf.format(percentFree)+"%) free of "+(buf.substring(start+1,start+12)).trim()+"|storage="+(int)(100-percentFree)+";"+(int)(ARGS.tHoldWarn)+";"+(int)(ARGS.tHoldCritical)+";0;100");
		}

		 */
		else if(ARGS.checkVariable==JOBS){
			if(buffer.indexOf(LANG.DB_CAPABILITY)!=-1){
				start=findToken(buffer,":",11)+1;
			}
			else{
				start=findToken(buffer,":",9)+1;
			}
			int jobs=(new Integer((buffer.substring(start,start+11)).trim())).intValue();

			returnStatus=getStatus(jobs);

			safePrintln(jobs+" jobs in system | jobs="+jobs+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
		}
		else if(ARGS.checkVariable==DBFault){
			start=findToken(buffer,"+",5)+2;
			String sDB1F=(new String((buffer.substring(start,start+6)))).trim();
			double DB1F=(new Double(checkDouble(sDB1F.substring(0,sDB1F.length())))).doubleValue();
			start=findToken(buffer,"+",5)+9;
			String sNonDB1F=(new String((buffer.substring(start,start+6)))).trim();
			double NonDB1F=(new Double(checkDouble(sNonDB1F.substring(0,sNonDB1F.length())))).doubleValue();

			//OS check
			if(buffer.indexOf(LANG.DB_CAPABILITY)!=-1){
				start=1207;
				String sDB2F=(new String((buffer.substring(start,start+6)))).trim();
				double DB2F=(new Double(checkDouble(sDB2F.substring(0,sDB2F.length())))).doubleValue();
				start=1221;
				String sNonDB2F=(new String((buffer.substring(start,start+6)))).trim();
				double NonDB2F=(new Double(checkDouble(sNonDB2F.substring(0,sNonDB2F.length())))).doubleValue();
				double totDB1F=DB1F+NonDB1F;
				returnStatus=getStatus(totDB1F);
				safePrintln("POOL 1: "+DB1F+" / "+NonDB1F+", POOL 2: "+DB2F+" / "+NonDB2F+" (DB / Non-DB Fault) | Pool1dbf="+DB1F+";;;0; Pool1ndbf="+NonDB1F+";;;0; Pool2dbf="+DB2F+";;;0; Pool2ndbf="+NonDB2F+";;;0; ");
			}
			else{
				start=1171;
				String sDB2F=(new String((buffer.substring(start,start+6)))).trim();
				double DB2F=(new Double(checkDouble(sDB2F.substring(0,sDB2F.length())))).doubleValue();
				start=1185;
				String sNonDB2F=(new String((buffer.substring(start,start+6)))).trim();
				double NonDB2F=(new Double(checkDouble(sNonDB2F.substring(0,sNonDB2F.length())))).doubleValue();
				double totDB1F=DB1F+NonDB1F;
				returnStatus=getStatus(totDB1F);
				safePrintln("POOL 1: "+DB1F+" / "+NonDB1F+", POOL 2: "+DB2F+" / "+NonDB2F+" (DB / Non-DB Fault) | Pool1dbf="+DB1F+";;;0; Pool1ndbf="+NonDB1F+";;;0; Pool2dbf="+DB2F+";;;0; Pool2ndbf="+NonDB2F+";;;0; ");
			}
		}

		return returnStatus;
	}
	
	
	
	public static int parseCmdClp(String buffer){
		int start=0;
		int returnStatus=UNKNOWN;
		NumberFormat nf=NumberFormat.getInstance();
		nf.setMaximumFractionDigits(0);

		String CMD=ARGS.cmdCL;
		
		if (ARGS.cmdCL.toUpperCase().indexOf("/") != -1){
		  String[] array = ARGS.cmdCL.toUpperCase().split("/");
		  CMD=array[1];
		}
		
		if(CMD.equals("DISKBUSY")){
			start=findToken(buffer,"000001",1)+7;
			double num1=(new Double(checkDouble((buffer.substring(start,start+9)).trim()))).doubleValue();
			returnStatus=getStatus(num1);
			safePrintln("Disk Busy avg:("+nf.format(num1)+"%). | cnt="+nf.format(num1)+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
		}
		else if(CMD.equals("TRSCOUNT")){
			start=findToken(buffer,"000001",1)+7;
			Double num1=(new Double(checkDouble((buffer.substring(start,start+16)).trim()))).doubleValue();
			Double Teller1=(new Double(checkDouble((buffer.substring(start+19,start+32)).trim()))).doubleValue();
			Double MyBank1=(new Double(checkDouble((buffer.substring(start+35,start+48)).trim()))).doubleValue();
			try{
			DecimalFormat f=new java.text.DecimalFormat("");
			Number num = f.parse(buffer.substring(start,start+16).trim());
			Number Teller = f.parse(buffer.substring(start+19,start+32).trim());
			Number MyBank = f.parse(buffer.substring(start+35,start+48).trim());
			num1 = (Double)num.doubleValue();
			Teller1 = (Double)Teller.doubleValue();
			MyBank1 = (Double)MyBank.doubleValue();
      }catch(Exception e)
      {
      	safePrintln("Unable to parse date strings:" +num1);
      }
		  returnStatus=getStatus(num1);
			safePrintln("IFX transactions: "+nf.format(num1)+", Teller: "+nf.format(Teller1)+", MyBank: "+nf.format(MyBank1)+". | cnt="+nf.format(num1)+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; teller="+nf.format(Teller1)+";;;0; mybank="+nf.format(MyBank1)+";;;0; ");
		}
		else{
	    start=findToken(buffer,"000001",1)+7;
			Double num1=(new Double(checkDouble((buffer.substring(start,start+9)).trim()))).doubleValue();
			returnStatus=getStatus(num1);
			safePrintln(CMD+": ("+nf.format(num1)+"). | cnt="+nf.format(num1)+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
	  }
		return returnStatus;
	}


	/**
	 * This function substitutes the parseDskSysSts() method
	 * 
	 * This implements not not only the search for FAILED and In ERROR, but gives
	 * Busy, degraded, hdw fail, pwr loss
	 */
	private static int parseWrkDskSts(String buffer){
		
		int returnStatus=UNKNOWN;
		String retString = "",retPerfdata = "";
		int p1=0;
		String failcnt="No",busycnt="No",degcnt="No",hdwcnt="No",pwlose="No";
		int i=0;
		int dskloadcrit=0,dskloadwarn=0;
		boolean botflag=true;

		if(ARGS.checkVariable==DISK){

			while(botflag || i >20){
				if(buffer.indexOf("FAILED")!=-1){
					failcnt="Yes";
				}
				if(buffer.indexOf("BUSY")!=-1){
					busycnt="Yes";
				}
				if(buffer.matches(".*DEGRADED.*")){
					degcnt="Yes";
				}
				if(buffer.matches(".*HDW FAIL.*")){
					hdwcnt="Yes";
				}
				if(buffer.indexOf("PWR LOSS")!=-1){
					pwlose="Yes";
				}
				if(buffer.indexOf(LANG.LIST_END)!=-1){
					botflag=false;
				}
				else{
					send((char)27+"z");
					buffer=waitReceive("F3=",NONE);
					i++;
				}
			}

			if(failcnt=="Yes" || busycnt=="Yes" || degcnt=="Yes" || hdwcnt=="Yes" || pwlose=="Yes"){
				System.out.print("CRITICAL - ");
				returnStatus=CRITICAL;
			}
			else if(i>20){
				System.out.print("UNKNOWN - More then 20 page. Stop check.  ");
				returnStatus=UNKNOWN;
			}
			else{
				System.out.print("OK - ");
				returnStatus=OK;
			}
			safePrintln("FAILED:"+failcnt+", BUSY:"+busycnt+", DEGRADED:"+degcnt+", HDW FAIL:"+hdwcnt+", PWR-LOSS:"+pwlose);

		} else if (ARGS.checkVariable==DISKLOAD){

			//Loop trough all Disks
			int load;
			String output = "";
			String strSearch = "";
			for (int j = 1; j < 10; j++){
			
				//Find Disk 1
				strSearch = new String("       "+j);
				if(ARGS.DEBUG) safePrintln("Searching for Disk Number: "+strSearch);
				p1=buffer.indexOf(strSearch);
				//p1=findToken(buffer,strSearch,1);
				if (p1 != -1){

					if(ARGS.DEBUG) safePrintln("Parsing result Disk "+j+" Start index: " + p1);
					load = Integer.parseInt(buffer.substring(p1+75,p1+82).trim());
					if(ARGS.DEBUG) safePrintln("The Disk Status Load: " + load);

					if (load > ARGS.tHoldCritical){
						dskloadwarn++;
						retString += "CRITICAL Disk: " +j+" Load: "+load+"; ";
						retPerfdata += "disk_"+j+"="+load+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+" ";
					} else if (load > ARGS.tHoldWarn){
						dskloadcrit++;
						retString += "WARNING Disk: " +j+" Load: "+load+"; ";
						retPerfdata += "disk_"+j+"="+load+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+" ";
					} else {
						retString += "Disk: " +j+" Load: "+load+"; ";
						retPerfdata += "disk_"+j+"="+load+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+" ";
					}
				} else {
					i = 1000;
				}
			}
                        //String DiskLoad = (new String((buf.substring(p1+40,p1+60)))).trim();
			//if(ARGS.DEBUG) safePrintln("The Disk Status Load: " + DiskLoad);
			if (dskloadcrit > 0){
				returnStatus=CRITICAL;
				System.out.print("CRITCAL: "+retString+" | "+retPerfdata);
			} else if (dskloadwarn > 0){
				returnStatus=WARN;
				System.out.print("WARNING: "+retString+" | "+retPerfdata);
			} else {
				returnStatus=OK;
				System.out.print("OK: "+retString+" | "+retPerfdata);
			}
		}

		return returnStatus;
	}
	
	
	/**
	 * Read the Problem Log
	 * Merged from WP
	 * TODO To translate
	 */
	private static int parseDspPrb(String buffer){
		
		int p1=0;
		int p2=0;
		int returnStatus=UNKNOWN;
		String buf;

		if(ARGS.checkVariable==DSPPRB){
			
			//p1=buffer.indexOf("disponibile alcun record di problema che contenga i dati");
			p1=buffer.indexOf(LANG.DSPPRB_NoProblems);
			if(ARGS.DEBUG) safePrintln("Sending other F3...");
			send((char)27+"3");
			waitReceive("===>",NONE);
			send("dspprb status(*ready)\r");
			//buf=waitReceive("Visualizzazione problemi",DSPPRB);
			buf=waitReceive(LANG.DSPPRB_PageLabel,DSPPRB);
			if(ARGS.DEBUG) safePrintln(buf);
			// START WP
			p2=buf.indexOf(LANG.DSPPRB_NoProblems);
			// END
			//p2=buf.indexOf("disponibile alcun record di problema che contenga i dati");
			
			if (p1 == -1) {
				
				returnStatus=WARN;
				//p1=buffer.indexOf("Descrizione problema");
				p1=buffer.indexOf(LANG.DSPPRB_ProblemDescr);
				buf=buffer.substring(p1+53,p1+120);
				safePrintln("WARNING - there are opened problems ("+buf+")");
				
			} else if (p2 == -1) {
				
				returnStatus=WARN;
				p1=buffer.indexOf(LANG.DSPPRB_ProblemDescr);
				//p1=buf.indexOf("Descrizione problema");
				buf=buf.substring(p1+53,p1+120);
				safePrintln("WARNING - there are ready problems ("+buf+")");
				
			} else {
				
				returnStatus=OK;
				safePrintln("OK - no open problem detected");
			}
		}
		
		return returnStatus;
	}
	
	/**
	 * Parse Result from Command: milobr/ctlmsgw3c
	 * Merged from WP
	 */
	private static int parseCtlMsgw(String buffer){

		int p1=0;
		int returnStatus=UNKNOWN;
		String buf;
			
		p1=buffer.indexOf("SBS");
		if (p1 != -1) {
			returnStatus=WARN;
			buf=buffer.substring(p1);
			p1=buf.indexOf("*****");
			buf=buf.substring(0,p1).trim();
			safePrintln("WARNING - there is a job in 'MSGW' ("+buf+")");
			
		} else {
			returnStatus=OK;
			safePrintln("OK - no jobs in 'MSGW'");
		}
		send((char)27+"3");

		return returnStatus;
	}

	/**
	 * Parse System Log messages
	 * This called by: DSPLOG. dsplog log("+ARGS.logName+") period(("+ARGS.fromTime+") ("+ARGS.toTime+"))
	 * This called by: DSPMSGQ. dspmsg msgq("+ARGS.msgUser+") start(*FIRST)
	 * Merged from WP
	 */
	public static int parseDspLog(String buffer){
		
		int p1=0;
		int p2=0;
		int returnStatus=UNKNOWN;
		String buf;

		// Critical IF found
		if(ARGS.checkVariable==vDSPLOG){
			
			p1=buffer.indexOf(ARGS.searchString);
			if (p1 != -1) {
				returnStatus=CRITICAL;
				buf=buffer.substring(p1);
				p2=80;
				safePrintln("CRITICAL - found string: "+buf.substring(0,p2));
			
				p1 = p1 - 6;
				Pattern p = Pattern.compile("^(\\d+)\\s+");
				Matcher matcher = p.matcher(buffer.substring(p1));
				if (matcher.find()) {
					safePrintln(matcher.group());
				}
				//buf=buffer.substring(p1, p2);
				//safePrintln("CRITICAL - found string: "+buf.substring(0,8));
			} else {
				returnStatus=OK;
				safePrintln("OK - string not found: " + ARGS.searchString);
			}
		}
		
		// Critical IF NOT found
		if(ARGS.checkVariable==vDSPLOGN){
			
			p1=buffer.indexOf(ARGS.searchString);
			if (p1 == -1) {
				returnStatus=CRITICAL;
				safePrintln("CRITICAL - string not found: " + ARGS.searchString);
			} else {
				returnStatus=OK;
				safePrintln("OK - found string ("+ARGS.searchString+")");
			}
		}

		// Critical IF found
		if(ARGS.checkVariable==vDSPLOGPARSE){
			
			//safePrintln("SearchString: " + ARGS.searchString);
			p1=buffer.indexOf(ARGS.searchString);
			if (p1 != -1){

				returnStatus=OK;
                                buf=buffer.substring(p1);

                                p1 = p1 + ARGS.startIndex;
                                p2 = p1 + ARGS.indexLength;
			
				//safePrintln("Matching from " + p1 + " to " + p2);
				Pattern p = Pattern.compile("^(\\d+)\\s+");
				Matcher matcher = p.matcher(buffer.substring(p1,p2));
				if (matcher.find()) {
					safePrintln("Matched integer: " + matcher.group());
				}else{
					safePrintln("Matched text: " + buffer.substring(p1,p2));
				}
				//buf=buffer.substring(p1, p2);
				//safePrintln("CRITICAL - found string: "+buf.substring(0,8));
			} else {
				returnStatus=UNKNOWN;
				safePrintln("UNKNOWN - string not found: " + ARGS.searchString);
			}
		}

		return returnStatus;
	}
	
	
	public static int parseDspLogBRM(String buffer){
		
		int p1_MsgID = 0;
		int p1_MsgSev = 0;
		int returnStatus=UNKNOWN;
		String buf;
		String exitString = "";

		//No search results
		if (buffer.indexOf(LANG.NO_DSPLOGBRM_MESSAGE)!=-1){
			exitString = "CRITICAL - No BRM Backup activity found for Msg-ID: "+ARGS.logName+".";
			returnStatus=CRITICAL;

		// Critical IF found
		// Search for:
		//  Sendedat. Sendezeit Msg-ID   Bew. Bereich Job         Benutzer    Job Nr.        
		//  5.11.14   3:50:09  BRM1380   10  *BKU    CTL_SYS21T  QSECOFR     090665
		} else if(ARGS.checkVariable == vDSPLOGN ){
			
			p1_MsgID = buffer.indexOf(ARGS.logName);
			if (p1_MsgID != -1) {
			   buf=buffer.substring(p1_MsgID+9,p1_MsgID+13).trim();
			   if(ARGS.DEBUG) safePrintln("DEBUG: Substring buf: ("+buf+")");

			   p1_MsgSev = buf.indexOf(ARGS.searchString);
			   if (p1_MsgSev == -1){

				returnStatus=WARN;
				exitString = "WARNING - Backup Msg-ID "+ARGS.logName+" was found, but has Severity: " + buf;
			
			   } else {

				returnStatus=OK;
				exitString = "OK:  Backup Msg-ID "+ARGS.logName+" was found and Severity is: "+buf+".";
			   }
				
			} else {
				returnStatus = CRITICAL;
				exitString = "CRITICAL - BRM Msg-ID: "+ARGS.logName+" was not found for the selected Date: "+ARGS.logDate+" from Hour:  "+ARGS.fromTime+".";
			}
		}

		// In CASE of CRITICAL and IF an alternative Msg-ID is defined: Check for its presence
		if (( returnStatus == CRITICAL) && (ARGS.logBRMWarnID != null)){

		   if(ARGS.DEBUG) safePrintln("DEBUG: We should search for an alternative Msg-ID event: " + ARGS.logBRMWarnID);
		   //Send F3
		   send((char)27 + "3");
		   waitReceive("===>",NONE);

		   send("DSPLOGBRM PERIOD(("+ARGS.fromTime+" "+ARGS.logDate+")) MSGID("+ARGS.logBRMWarnID+")\r");
		   /*Wait and recieve output screen*/
		   waitReceive("Alternativsicht" ,DSPLOG);

		   send((char)27 + "[23~");

		   // Parse Screen holding the MSG-ID and Bewertung ID ( output id )
		   buffer = waitReceive(ARGS.logBRMWarnID , DSPLOG);
		   p1_MsgID = buffer.indexOf(ARGS.logBRMWarnID);

		   if (p1_MsgID != -1) {
			returnStatus=WARN;
			exitString = "WARNING - The Backup Msg-ID "+ARGS.logName+" FAILED, but the Warning ID "+ARGS.logBRMWarnID+" was found. Please check your Backups";
		   }

		}

		safePrintln(exitString);
		return returnStatus;
	}
	
	
	/**
	 * Read the CPI-Log
	 * Merged from WP
	 * TODO Translation missing
	 */
	public static int parseDspLogCpi(String buffer){
		
		int returnStatus=OK;
		String msg = "";

		if( ARGS.checkVariable == vDSPLOG ) {
			
			if (buffer.indexOf("Nessun messaggio disponibile") == -1){
				returnStatus = CRITICAL;
				msg = "CRITICAL - "+ARGS.searchString+": was found";
			} else {
				msg = "OK - "+ARGS.searchString+": not found";
			}
			
		} else if ( ARGS.checkVariable == vDSPLOGN) {
			
			if (buffer.indexOf("Nessun messaggio disponibile") != -1){
				returnStatus = CRITICAL;
				msg = "CRITICAL - "+ARGS.searchString+": not found";
			} else {
				msg = "OK - "+ARGS.searchString+": was found";
			}
		}

		safePrintln(msg);
		return returnStatus;
	}

	
	/**
	 * Check the user profile to exist and beeing not disabled
	 * Merged from WP
	 * TODO Translation missing
	 * 
	 */
	private static int parseUsrPrf(String buffer){

		int n=0;
		int returnStatus=OK;
		String msg = "";
		String pdat = "";
		String buf;

		if(buffer.indexOf("stato trovato il profilo utente") != -1){
			returnStatus = CRITICAL;
			msg = ARGS.prefUsers[n] + ":nonexistant";
			
		} else if (buffer.indexOf("DISABLED") != -1) {
			returnStatus = CRITICAL;
			msg = ARGS.prefUsers[n] + ":disabled";
			pdat = ARGS.prefUsers[n] + "=0";
			
		} else {
			pdat = ARGS.prefUsers[n] + "=1";
		}
		
		while(++n < ARGS.numPrefUsers) {
			
			send("\r");
			waitReceive("F3=Fine",NONE);
			send("dspusrprf usrprf("+ARGS.prefUsers[n]+")\r");
			
			/*Wait and recieve output screen*/
			buf=waitReceive("Profilo utente",USRPRF);
			
			if(buf.indexOf("stato trovato il profilo utente") != -1) {
				returnStatus = CRITICAL;
				
				if (msg == "") {
					msg = ARGS.prefUsers[n] + ":nonexistant";
					
				} else {
					msg = msg + ", " + ARGS.prefUsers[n] + ":nonexistant";
				}
				
				if (pdat == "") {
					pdat = ARGS.prefUsers[n] + "=0";
				} else {
					pdat = pdat + " " + ARGS.prefUsers[n] + "=0";
				}
				
			} else if (buf.indexOf("DISABLED") != -1) {
				
				returnStatus = CRITICAL;
				if (msg == "") {
					msg = ARGS.prefUsers[n] + ":disabled";
				} else {
					msg = msg + ", " + ARGS.prefUsers[n] + ":disabled";
				}
				if (pdat == "") {
					pdat = ARGS.prefUsers[n] + "=0";
				} else {
					pdat = pdat + " " + ARGS.prefUsers[n] + "=0";
				}
				
			} else {
				
				if (pdat == "") {
					pdat = ARGS.prefUsers[n] + "=1";
				} else {
					pdat = pdat + " " + ARGS.prefUsers[n] + "=1";
				}
			}
		}
		
		if (returnStatus != OK) {
			if (msg == "")
				safePrintln("CRITICAL - You have user problems|"+pdat);
			else
				safePrintln("CRITICAL - You have user problems ("+msg+")|"+pdat);
		} else {
			if (msg == "")
				safePrintln("OK - All checked users are enabled|"+pdat);
			else
				safePrintln("OK - All checked users are enabled ("+msg+")|"+pdat);
		}
		return returnStatus;
	}

	
	/**
	 * Call a Programm in As/400
	 * 
	 * Merged from WP
	 * 
	 */
	private static int parseCallProg(String buffer){
		
           int returnStatus=UNKNOWN;

	   if (buffer != null) {
              if (buffer.indexOf(ARGS.searchString)!=-1) {
                 safePrintln("OK - CALL executed sucessfully");
                 returnStatus=OK;
              } else {
                 safePrintln("CRITICAL - CALL executed with ERRORS");
                 returnStatus=CRITICAL;
              }
           } else {
              safePrintln("CRITICAL - No status returned from CALL");
              returnStatus=UNKNOWN;
           }
	   return returnStatus;
	}
	
	/**
	 * Check the ASP
	 */
	private static int parseWrkAspBrm(String buffer){
		
		int start=0;
		int returnStatus=UNKNOWN;		
		start=findToken(buffer,"Used",1)+201;
		double useds=(new Double(checkDouble((buffer.substring(start,start+5)).trim()))).doubleValue();
		returnStatus=getStatus(useds);
		if(returnStatus==OK){
			safePrintln(useds+"% used in ASP "+ARGS.aspNums+" | asp="+useds+"%;"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
		}
		else {
			safePrintln(useds+"% used in ASP "+ARGS.aspNums+"! | asp="+useds+"%;"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
		}
		return returnStatus;
	}	

	
	/**
	 * Parse if a Problem has been found
	 * @param buffer
	 * @return
	 */
	private static int parseWrkPrb(String buffer){
		
		int count=0;
		int count1=0;
		String buffer1 = buffer;
		int returnStatus=UNKNOWN;
		while(buffer1.indexOf("PREPARED")!=-1){
			buffer1 = buffer1.substring(buffer.indexOf("PREPARED") + 8); 
			count1++;
		}
		while(buffer.indexOf("OPENED")!=-1){
			buffer = buffer.substring(buffer.indexOf("OPENED") + 6); 
			count++; 
			returnStatus=CRITICAL;
		}
		if (count==0){returnStatus=OK;}
		safePrintln("There are "+count+" OPENED / "+count1+" PREPARED status problems. | prb="+count+";1;1;0; ");
		return returnStatus;
	}	

	/**
	 * CPU load, Consider Current processing capacity.
	 * @param buffer
	 * @return
	 */
	private static int parseWrkSysAct(String buffer){
		
		int start=0;
		int returnStatus=UNKNOWN;		
		start=findToken(buffer,":",11)+1;
		double cpunums=(new Double(checkDouble((buffer.substring(start,start+9)).trim()))).doubleValue();

		send((char)27+"3");
		waitReceive("F3=",NONE);
		send("WRKSYSSTS\r");
		buffer=waitReceive("F3=",NONE);
		start=findToken(buffer,":",3)+1;
		double cpus=(new Double(checkDouble((buffer.substring(start,start+11)).trim()))).doubleValue();
		returnStatus=getStatus(cpus);

		double capc = Double.parseDouble(ARGS.cpuNum);
		NumberFormat   nbf=NumberFormat.getInstance();
		nbf.setMinimumFractionDigits(2);
		String   truecpu   =   nbf.format(cpus*cpunums/capc);

		safePrintln("CPU Load("+cpus+"%),Capacity("+cpunums+"), True CPU Load("+truecpu+"%) | CPU="+truecpu+"%;;;0; CPUO="+cpus+"%;0;0;0; CPUS="+cpunums+"unit;"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
		return returnStatus;
	}
	
	/**
	 * Check MIMIX Data Group Unprocessed Entry Count, Transfer definition, RJ link state.
	 * @param buffer
	 * @return
	 */
	private static int parseDspDgSts(String buffer){
		
		int start=0;
		int returnStatus=UNKNOWN;		
		start=findToken(buffer,"DB  Apply-",1)+40;
		String unprocessS = (new String((buffer.substring(start,start+12)))).trim();
		
		if (unprocessS.equals("")){
			unprocessS = "0";
		}
		else{
			unprocessS = unprocessS.replaceAll(",", "");
		}
		int unprocess = Integer.parseInt(unprocessS);

		//Find Object in error
		//int start1=0;
		//start1=findToken(buffer,":",8)+1;
		//int objerr = (new Integer((buffer.substring(start1,start1+7)).trim())).intValue();

		returnStatus=getStatus(unprocess);
		//if (objerr > 0){
		//	returnStatus=CRITICAL;
		//}
		//safePrintln(ARGS.dgDef+" Unprocessed Entry Count :"+unprocess+", Object error:"+objerr+" | unp="+unprocess+";1000000;2000000;0; objerr="+objerr+";1;1;0; ");

		String TRD="PRIMARY-A";
		if(buffer.indexOf("PRIMARY-I")!=-1){
			System.out.print("But Transfer definition not active. ");
			returnStatus=CRITICAL;
		}
		if(buffer.indexOf("SYNC")==-1){
			System.out.print("But Remote journal link inactive. ");
			returnStatus=CRITICAL;
		}
		start=findToken(buffer,":",10)+1;
		String SyncState = (new String((buffer.substring(start,start+12)))).trim();

		safePrintln(ARGS.dgDef+" Unprocessed Entry Count:"+unprocess+", TRD:"+TRD+", RJL State:"+SyncState+" | unp="+unprocess+";"+ARGS.tHoldWarn+";"+ARGS.tHoldCritical+";0; ");
		return returnStatus;
	}

	
	/**
	 * Check for any Inactive or Failed Node status
	 * @param buffer
	 * @return
	 */
	private static int parseICNodeSts(String buffer){
		int returnStatus=UNKNOWN;
		String failcnt="No",inactcnt="No",unkncnt="No";
		int i=0;    
		boolean botflag=true;

		if(ARGS.checkVariable==ICNODE){
			while(botflag || i >20){
				if(buffer.indexOf("FAILED")!=-1){
					failcnt="Yes";
				}
				if(buffer.indexOf("INACTIVE")!=-1){
					inactcnt="Yes";
				}
				if(buffer.indexOf("UNKNOWN")!=-1){
					unkncnt="Yes";
				}
				if(buffer.indexOf(LANG.LIST_END)!=-1){
					botflag=false;
				}
				else{
					send((char)27+"z");
					buffer=waitReceive("F3=",NONE);
					i++;
				}
			}
			if(failcnt=="Yes" || inactcnt=="Yes" || unkncnt == "Yes"){
				System.out.print("CRITICAL - ");
				returnStatus=CRITICAL;
			}
			else if(i>20){
				System.out.print("UNKNOWN - More then 20 page. Stop check.  ");
				returnStatus=UNKNOWN;
			}
			else{
				System.out.print("OK - ");
				returnStatus=OK;
			}
			safePrintln("FAILED:"+failcnt+", INACTIVE:"+inactcnt+", UNKNOWN:"+unkncnt);
		}

		return returnStatus;
	}

	
	/**
	 * Check for any Inactive or Indoubt Group status
	 * @param buffer
	 * @return
	 */
	private static int parseICGrpSts(String buffer){
		
		int returnStatus=UNKNOWN;
		String indbtcnt="No",inactcnt="No",unkncnt="No",nonecnt="No",errcnt="No",swocnt="No",befxcnt="No",stscnt="No",strjcnt="No",trgcnt="No",chkidcnt="No",constrcnt="No",chgrlcnt="No",mrkpcnt="No",aftxcnt="No",rsscnt="No",endapycnt="No";
		int i=0;    
		boolean botflag=true;
		
		if(ARGS.checkVariable==ICGROUP){
			
			while(botflag || i >20){
				if(buffer.indexOf("*INDOUBT")!=-1){
					indbtcnt="Yes";
				}
				if(buffer.indexOf("*INACTIVE")!=-1){
					inactcnt="Yes";
				}
				if(buffer.indexOf("*UNKNOWN")!=-1){
					unkncnt="Yes";
				}
				if(buffer.indexOf("*NONE")!=-1){
					nonecnt="Yes";
				}
				if(buffer.indexOf("IN_ERROR")!=-1){
					errcnt="Yes";
				}              
				if(buffer.indexOf(LANG.LIST_END)!=-1){
					botflag=false;
				}
				else{
					send((char)27+"z");
					buffer=waitReceive("F3=",NONE);
					i++;
				}
			}
			if(inactcnt=="Yes"){
				System.out.print("WARNING - ");
				returnStatus=WARN;
			}
			else if(indbtcnt=="Yes" || unkncnt == "Yes" || nonecnt == "Yes" || errcnt == "Yes"){
				System.out.print("CRITICAL - ");
				returnStatus=CRITICAL;
			}
			else if(i>20){
				System.out.print("UNKNOWN - More then 20 page. Stop check.  ");
				returnStatus=UNKNOWN;
			}
			else{
				System.out.print("OK - ");
				returnStatus=OK;
			}
			safePrintln("INDOUBT:"+indbtcnt+", INACTIVE:"+inactcnt+", UNKNOWN:"+unkncnt+", NONE:"+nonecnt+", IN_ERROR:"+errcnt);
		}

		return returnStatus;
	}    

  
	/**
	 * Check for multiple conditions for switch readiness
	 * @param buffer
	 * @return
	 */
	private static int parseICSwRdySts(String buffer){
		
		int returnStatus=UNKNOWN;
		String ntvldcnt="No",suscnt="No",ooscnt="No",latcnt="No",cmtcnt="No";
		int i=0;
		
		if(ARGS.checkVariable==ICSWRDY){
			
			if(buffer.indexOf("code 1")!=-1){
				ntvldcnt="Yes";
				safePrintln("CRITICAL - Group not valid for a roleswap.");
				returnStatus=CRITICAL;
			}
			else if(buffer.indexOf("code 2")!=-1){
				suscnt="Yes";
				safePrintln("WARNING - Group has suspended objects");
				returnStatus=WARN;
			}
			else if(buffer.indexOf("code 3")!=-1){
				ooscnt="Yes";
				safePrintln("WARNING - Group has Out Of Sync objects");
				returnStatus=WARN;
			}
			else if(buffer.indexOf("code 4")!=-1){
				latcnt="Yes";
				safePrintln("WARNING - Group latency is exceeding user defined thresholds");
				returnStatus=WARN;
			}
			else if(buffer.indexOf("code 5")!=-1){
				cmtcnt="Yes";
				safePrintln("WARNING - Group has open commitment control cycles present");
				returnStatus=WARN;
			}
			else{
				safePrintln("OK - Group is switch-ready based on user parameters");
				returnStatus=OK;
			}  
		}

		return returnStatus;
	}		

  
	/**
	 * Query a DB over a JDBC connection
	 * @return
	 */
	private static int performJDBC_Query(){

		String buffer;	
		int returnStatus=UNKNOWN;
		ResultSet rs = null;
		String value = "";
		Connection connection;
		Statement stmt;

		try {

			if (ARGS.DEBUG) safePrintln("Trying JDBC connection to host: "+ARGS.hostName+" username: "+ARGS.userName+" passwd: "+ARGS.passWord+"\n");
			DriverManager.setLoginTimeout(30);

			java.util.Properties driverProd = new java.util.Properties();
			driverProd.setProperty("user",ARGS.userName);
			driverProd.setProperty("password",ARGS.passWord);
			Class jdbcDriver = Class.forName("com.ibm.as400.access.AS400JDBCDriver");
			connection = ((java.sql.Driver)jdbcDriver.newInstance()).connect("jdbc:as400://"+ARGS.hostName+";translate binary=true;",driverProd);

			if ( ARGS.dbQuery == "" ){

				safePrintln("Exception: No SQL query has been passed!");
				throw new Exception();
			}

			if (ARGS.DEBUG) safePrintln("SQL Query: "+ARGS.dbQuery);

			//String sql = "SELECT * FROM B27165.LGVAL00F";
			String sql = ARGS.dbQuery;
			stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);

			ResultSetMetaData rsmd = rs.getMetaData();

			//The Number and names of columns
			int NumOfCol=rsmd.getColumnCount();

			// The column count starts from 1
			String columnNames = "Number of Columns="+NumOfCol+" Column Names: ";
			String[] arr_columnName = new String[NumOfCol];
			for (int i = 1; i < NumOfCol + 1; i++ ) {

				columnNames += rsmd.getColumnName(i)+" | ";
				arr_columnName[i-1] = rsmd.getColumnName(i);
			}

			if (ARGS.DEBUG) safePrintln(columnNames);

			// process results one row at a time
			while (rs.next()) {

				String rowdata = "";
				for(int j=1;j<NumOfCol + 1;j++){

					String val = rs.getString(j);
					rowdata += arr_columnName[j-1]+": "+ val+"; ";
				}
				safePrintln(rowdata);
				/*   int key = rs.getInt(1);
			       String val = rs.getString(2);

			       safePrintln("key = " + key);
			       safePrintln("val = " + val);
				 */
			}

			//  while(rs.next()){
			//	 value = rs.getString(1);
			//	 safePrintln("The value: "+value);
			//  }
			if(rs != null)rs.close();
			if (stmt != null) stmt.close();
			if (connection != null) connection.close(); 

			if (ARGS.DEBUG) safePrintln("Terminated and connection closed !");
		} catch (Exception e) {

			safePrintln("CRITICAL - SQL failed");
			if (ARGS.DEBUG) e.printStackTrace();
		}

		return 3;
	}


	/*
	 * Perform login
	 */
	private static boolean login(){

		//if(ARGS.DEBUG) safePrintln("  sending hello...");
		/*send hello so the server will send login screen*/
		//send((char)27+"");

		if(ARGS.DEBUG) safePrintln("  waiting for screen...");
		/*Wait for the login screen*/
		if(waitReceive("IBM CORP",NONE)!=null){
			
			if(ARGS.DEBUG) safePrintln("  sending login information for "+ARGS.userName+"...");
			
			/*send login user/pass*/
			send(ARGS.userName+"\t");
			send(ARGS.passWord+"\r");

			if(ARGS.DEBUG) safePrintln("  waiting for login to process...");
			/*Wait and recieve command screen*/
			if(waitReceive("===>",LOGIN)!=null)
				return true;
		}

		return false;
	}	

	/**
	 * Identify the OS version
	 * @return
	 */
	public static boolean getOSVersion() {
		
		String buf;

		if(ARGS.DEBUG) safePrintln("Get OS Version");
		
		send("dspptf\r");
		
		/*Wait for the ptf screen*/
		buf=waitReceive(LANG.LOGIN_SYS_SCREEN, NONE);
		
		if (buf != null) {
			if(buf.indexOf("V5R3")!=-1 || buf.indexOf("V4R3")!=-1) {
				if(ARGS.DEBUG) safePrintln("Version V5R3 found\n");
				ARGS.osversion=5.3;
			}
		}
		
		//send F3
		if(ARGS.DEBUG) safePrintln("Sending F3...");
		send((char)27+"3");
		waitReceive("===>",NONE);

		return true;
	}
  
	
	/**
	 * Recieves all info in stream until it see's the string 'str'.
	 * 
	 * Adaptation by WP to be tolerant for slow terminals and long list of logs
	 */
	private static String waitReceive(String str, int procedure){
		String buffer=new String();
		String actbuffer;
		boolean flag=true;

		if(ARGS.DEBUG) safePrintln("    waiting for token "+str+"...");

		buffer="";
		actbuffer="";
		try{
			int cicleCounter = 0;

			while(flag){

				Thread.sleep(5);
				if (cicleCounter++ > 100000)
					flag = false;

				int ch;
				while((ch=ioReader.read())!=-1){
					actbuffer=actbuffer+(char)ch;
					cicleCounter = 0;

					if(ioReader.ready()==false)
						break;
				}
				if(ARGS.DEBUG_PLUS) safePrintln("\n**BUFFER IS:**\n"+actbuffer+"\n**END OF BUFFER**\n");
				if(procedure==LOGIN){
					if(actbuffer.indexOf("CPF1107")!=-1){
						safePrintln("CRITICAL - Login ERROR, Invalid password");
						close();
						System.exit(CRITICAL);
					}
					else if(actbuffer.indexOf("CPF1120")!=-1){
						safePrintln("CRITICAL - Login ERROR, Invalid username");
						close();
						System.exit(CRITICAL);
					}
					else if(actbuffer.indexOf("/"+ARGS.userName.toUpperCase()+"/")!=-1){
						if(ARGS.DEBUG) safePrintln("      responding to allocated to another job message...");
						send("\r");
						actbuffer="";
					}
					else if(actbuffer.indexOf(LANG.PASSWORD_HAS_EXPIRED)!=-1){
						//else if(buffer.indexOf("Password has expired")!=-1){
						send((char)27+"3");
						//waitReceive(LANG.EXIT_SIGNON,NONE);
						waitReceive("Exit sign-on request",NONE);
						send("Y\r");
						safePrintln("WARNING - Expired password, Please change it.");
						close();
						System.exit(WARN);
					}
					// Password is going to expiree
					//else if(actbuffer.indexOf(LANG.PASSWORD_EXPIRES)!=-1){
					//	//else if(buffer.indexOf("Days until password expires")!=-1){
					//	send((char)27+"3");
					//	//waitReceive(LANG.EXIT_SIGNON,NONE);
					//	waitReceive("Exit sign-on request",NONE);
					//	send("Y\r");
					//	safePrintln("WARNING - Expired password, Please change it.");
					//	close();
					//	System.exit(WARN);
					//}
					else if(actbuffer.indexOf("CPF1394")!=-1){
						safePrintln("CRITICAL - Login ERROR, User profile NAGIOS cannot sign on.");
						close();
						System.exit(CRITICAL);
					}
					else if(actbuffer.indexOf(LANG.LAST_LOGIN_INFO)!=-1){
						if(ARGS.DEBUG) safePrintln("      responding to last Login Date info message...");
						send("\r");
						actbuffer="";
					}
					else if(actbuffer.indexOf(LANG.DISPLAY_MESSAGES)!=-1){
						if(ARGS.DEBUG) safePrintln("      continuing through message display...");
						send((char)27+"3");
						actbuffer="";
					}
					else if(actbuffer.indexOf(LANG.EnterToContinue)!=  -1){
						if(ARGS.DEBUG) safePrintln("      responding to "+ LANG.EnterToContinue +" to continue message...");
						send("\r");
						actbuffer="";
					}
				}
				else if(procedure==GETOUTQ){
					if(actbuffer.indexOf(LANG.NO_OUTPUT_QUEUES)!=-1){
						safePrintln("CRITICAL - outq "+ARGS.outQ+" does NOT exist");
						logout(CRITICAL);
					}
				}
				else if(procedure==GETSBSD){
					if(actbuffer.indexOf(LANG.NOT_FOUND)!=-1){
						safePrintln("CRITICAL - subsystem("+ARGS.subSystem+") NOT IN SYSTEM");
						logout(CRITICAL);
					}
				}
				else if(procedure==GETFD){
					if(actbuffer.indexOf(LANG.NOT_FOUND)!=-1){
						safePrintln("CRITICAL - FD object ("+ARGS.fdFile+") NOT IN SYSTEM");
						logout(CRITICAL);
					}
				}
				else if(procedure==GETJOB){
					if(actbuffer.indexOf(LANG.DUPLICATE)!=-1){
						if(actbuffer.indexOf("ACTIVE")!=-1){
							if(ARGS.DEBUG) safePrintln("Found duplicate sending 1 on first row!!!\n");
							send("1\r");
						} else {
							safePrintln("WARNING - Duplicate Jobs("+ARGS.job+")");
							send((char)27+"3");
							waitReceive("===>",NONE);
							logout(CRITICAL);
						}
					}
					if(actbuffer.indexOf(LANG.JOB)!=-1){
						safePrintln("CRITICAL - job("+ARGS.job+") NOT IN SYSTEM");
						logout(CRITICAL);
					}
				}
				else if(procedure==USRPRF){
					if(actbuffer.indexOf("stato trovato il profilo utente")!=-1){
						if(ARGS.DEBUG) safePrintln("    backup token received.");
						return actbuffer;
					} else if (actbuffer.indexOf("Non si dispone dell'autorizzazione per il profilo utente")!=-1) {
						safePrintln("CRITICAL - Non authorized to visualize the user porfiles!");
						logout(CRITICAL);
					}
				}

				//check for command not allowed errors
				if(procedure!=LOGIN){
					if(buffer.indexOf(LANG.LIBRARY_NOT_ALLOWED)!=-1){
						send((char)27+"3");
						safePrintln("CRITICAL - Command NOT allowed");
						logout(CRITICAL);
					}
				}
				if(procedure != WRKJOBQ && procedure != DISK && actbuffer.indexOf(str)!=-1)
					flag=false;


				/*
				 * Perform check also if already fond, since More... might be on the page and keep buffer
				 *  - go ahead only if the string has not jet for DSPLOG, DiskHardware check, Display Problems
				 *  - go ahead always till the end iff we are parsing the active jobs - there can be subsystems with the same name
				 *    so we have to read everything                  				 
				 */ 
				if( (flag && (procedure==DSPLOG || procedure==DISK || procedure==DSPPRB)) || procedure==WRKJOBQ){

					if(ARGS.DEBUG) safePrintln("      Getting next page(s)..." + procedure);
					//Do not scroll for next pages for DSPPkhlRB
					if (procedure==DSPPRB) continue;

					int p1 = actbuffer.indexOf(LANG.NEXT);
					if( p1 != -1 ){

						if(ARGS.DEBUG) safePrintln("      sending PageDown to get next messages...");
						send((char)27+"[6~");
						buffer=buffer+actbuffer;
						actbuffer="";

						//Empty buffer for DSPLOG since previous log scan was negative and text is often long
						if (procedure==DSPLOG) buffer="";

						//Continue reading on next pages, also if string fond, since QBATCH is often only a subsystem
						if (procedure==WRKJOBQ) flag=true;
					}
					//Reached End
					p1 = actbuffer.indexOf(LANG.END);
					if (p1 != -1) {
						flag=false;
					}
				}
			}
			
		} catch(Exception e) {	
			safePrintln("CRITICAL: Network error:"+e);
			return null;
		}

		if(ARGS.DEBUG) safePrintln("    token received.");

		buffer=buffer+actbuffer;
		return buffer;
	}

	
	/**
	 * Perform logout
	 * @param exitStatus
	 */
	private static void logout(int exitStatus){
		//send F3
		if(ARGS.DEBUG) safePrintln("Logging out...\n  sending F3...");
		send((char)27+"3");
		waitReceive("===>",NONE);

		if(ARGS.DEBUG) safePrintln("  requesting signoff...");
		//send logout
		send("signoff *nolist\r");
		//waitReceive(";53H",NONE);
		waitReceive(LANG.LOGIN_SCREEN,NONE);
		
		if(ARGS.DEBUG) safePrintln("Job ending immediately");
		send("\r");
		waitReceive(LANG.LOGIN_SCREEN,NONE);
		
		if(ARGS.DEBUG) safePrintln("  terminating connection...");

		close();
		if(ARGS.DEBUG) safePrintln("Logged out.");
		System.exit(exitStatus);
	}	

	
	/**
	 * open connection to server
	 * 
	 * Make use of Input Stream Reader, to allign the contents encoding
	 * @return
	 */
	private static boolean open() {

		try {

			ioSocket=new Socket(ARGS.hostName,23);
			ioSocket.setSoTimeout(10000);

			//ioWriter=new PrintWriter(ioSocket.getOutputStream(),true);
			ioWriter=new BufferedWriter(new OutputStreamWriter(ioSocket.getOutputStream(), "ISO8859_1"));
			ioReader=new BufferedReader(new InputStreamReader(ioSocket.getInputStream(), "ISO8859_1"));

			send("\n\r");

			return true;

		} catch(Exception e) {
			safePrintln("CRITICAL: Network error:"+e);
			return false;
		}
	}


	/**
	 * close connection to server
	 * @return
	 */
	private static boolean close() {
		try {
			ioSocket.close();
			return true;
		}
		catch (IOException e) {
			safePrintln("CRITICAL: Network error:"+e);
			return false;
		}
	}

	
	//read line from stream
	private static String read(){
		String str=new String();
		try{
			str=ioReader.readLine();
		}
		catch(Exception e) {
			safePrintln("CRITICAL: Network error: "+e);
			System.exit(CRITICAL);
		}
		return str;
	}
	
	
	//write str to stream
	private static void send(String str){
		try{
			//ioWriter.print(str);
			ioWriter.write(str);
			ioWriter.flush();
		}
		catch(Exception e) {
			safePrintln("CRITICAL: Network error: "+e);
			System.exit(CRITICAL);
		}	
	}
	
	
	/*
     * Safe Print, replacing non ASCII compliant and not Nagios conform chars 
     */
    public static void safePrintln(String input) {
		String output = input.replaceAll(allowedCharsRegex, "");
		System.out.println(output);
	}
    

    
	//Decode the incoming UTF-16 to char
	public static String decodeUTFCode(String origString){
	
		String finalString = origString;
		if(ARGS.DEBUG) safePrintln("Decoding UTF-16 String: '" + origString + "'");
		String pound = "#156#";
		int start = origString.indexOf(pound);
		if (start != -1){
		
			//char[] c = Character.toChars(129);
			char[] c = Character.toChars(163);
			finalString = origString.substring(0, start)+c[0]+origString.substring(start+5, origString.length());
			if(ARGS.DEBUG) safePrintln("Debug: The final string: '" + finalString + "'");
		}
		return finalString;
	}	

	private static Socket ioSocket;
	//private static PrintWriter ioWriter;
	private static BufferedWriter ioWriter;
	private static BufferedReader ioReader;
	private static check_as400_cmd_vars ARGS;
	private static check_as400_lang LANG;
	
	//These constants are for the Commands
	final static int WRKSYSSTS=0,WRKOUTQ=1,DSPMSG=2,DSPSBSD=3,DSPJOB=4,WRKACTJOB=5,CMDLOGIN=6,CMDCLP=7,WRKDSKSTS=8,WRKASPBRM=9,WRKSYSACT=10,DSPDGSTS=11,WRKJOBQ=12,CHKJOBSTS=13,DMWRKNODE=14,DMWRKGRP=15,DMSWTCHRDY=16,TOPCPUJOB=17,WRKPRB=18,DSPFD=19,DSPMSGQ=20,DSPPRB=21,CTLMSGW=22,DSPLOG=23,DSPLOGCPI=24,USRPRF=25,CALLPROG=26,JDBCQUERY=27,DSPLOGBRM=28;
	//These constants are for the variables
	final static int CPU=0,DB=1,US=2,JOBS=3,MSG=4,OUTQ=5,SBS=6,DJOB=7,AJOBS=8,DBFault=9,CMD=10,DISK=11,ASP=12,CPUC=13,MIMIX=14,JOBQ=15,JOBSTS=16,ICNODE=17,ICGROUP=18,ICSWRDY=19,CPUT=20,PRB=21,FDN=22,US720=23,vDSPLOG=24,vDSPLOGN=25,vDSPLOGPARSE=26,DISKLOAD=27;
	//These constants are for the wait recieve, controlling
	//any other logic that it should turn on. For example checking
	//for invalid login.
	final static int NONE=0,LOGIN=1,GETOUTQ=2,GETJOB=3,GETSBSD=4,GETFD=5;
	//Theses constants are the exit status for each error type
	final static int OK=0,WARN=1,CRITICAL=2,UNKNOWN=3;
	//These constants are used as flags on OUTQ
	final static int OUTQ_NW=1,OUTQ_NS=2,OUTQ_NF=4;
	//These constants are used as flags on JOBSTS
	final static int JOBSTS_NOPERM=1,JOBSTS_ONLYONE=2,JOBSTS_STATUS=4;
};
